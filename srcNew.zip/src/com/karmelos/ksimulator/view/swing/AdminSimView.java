/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.karmelos.ksimulator.view.swing;

//import com.jtattoo.plaf.aluminium.AluminiumLookAndFeel;
import com.karmelos.ksimulator.controller.SimAdminController;
import com.karmelos.ksimulator.jdialogs.OkCancelOption;
import com.karmelos.ksimulator.jdialogs.OkOption;
import com.karmelos.ksimulator.jdialogs.YesNoOption;
import com.karmelos.ksimulator.model.SimComponent;
import com.karmelos.ksimulator.model.SimModule;
import com.karmelos.ksimulator.model.SimModuleType;
import com.karmelos.ksimulator.model.SimUser;
import java.awt.Color;
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;


/**
 *
 * @author MorpheuS
 */
public class AdminSimView extends javax.swing.JFrame {

    private ImageIcon arrow;
    private JLabel[] temporaryLabels = new JLabel[6];
    private DefaultListModel listSimModuleTypes;
    private DefaultListModel listSimModules;
    private DefaultListModel listSimComponents;
    private DefaultListModel listSimComponentsCandidates;
    private DefaultListModel listSimComponentsSuccessors;
    private DefaultListModel adminCompTabListModel;
    private DefaultListModel listSimUsers;
    private DefaultListModel listSimComponentsSelected;
    private DefaultListModel listAllSimComponentsFor3d;
    private SimComponent selectedValue;
    private SimAdminController controller;
    private PopUpFrame puf;
    private SimModuleType presentSimModuleType;
    private List<SimComponent> temporaryList;
    private SimUser presentUsers;
    private SimModule presentModule;
    private byte[][] filebyte;
    private File[] fileout;
    private BufferedOutputStream output;
    private FileOutputStream[] outfile;
    private AdminAddModuleTypePane aamt;
    /**
     * Creates new form AdminSimView
     */
    @SuppressWarnings("empty-statement")
    public AdminSimView() {
        try {
            controller = new SimAdminController();
             puf= new PopUpFrame();
             
            listSimModuleTypes = new DefaultListModel();
            listSimModules = new DefaultListModel();
            listSimComponents = new DefaultListModel();
            adminCompTabListModel = new DefaultListModel();
            listSimComponentsCandidates = new DefaultListModel();
            listSimComponentsSelected = new DefaultListModel();
            listSimComponentsSuccessors = new DefaultListModel();
            listAllSimComponentsFor3d = new DefaultListModel();
            listSimUsers = new DefaultListModel();
            filebyte = new byte[3][];
            fileout = new File[3];
            outfile = new FileOutputStream[3];
            //load Moduletypes
            


            //load the module type ID combobox in the SimModule Admin tab
            // load first combobox

            arrow = new ImageIcon(ImageIO.read(this.getClass().getResource("../../2ndbaricon/adminarror.png")));
            setTitle("AdminUser View");

            this.setIconImage(ImageIO.read(this.getClass().getResource("../../2ndbaricon/Adminicon.png")));
            this.loadModuleTypeListModel(controller.fetchModuleTypes());
            this.loadSimUserListModel(controller.fetchSimUser());
            presentSimModuleType = new SimModuleType();
            initComponents();

            //set some components invisible
            deleteModuleType.setVisible(false);
            loadModuleTypeInfoBtn.setVisible(false);
            loadComponentInfo.setVisible(false);
            deleteComponent.setVisible(false);
            loadUserExisting.setVisible(false);
            deleteUserExisting.setVisible(false);
            addNewUserBtn.setVisible(false);
            clearTextField.setVisible(false);
            editModulePane.setVisible(false);
            deleteModule.setVisible(false);
            loadModuleInfo.setVisible(false);
            editPane.setVisible(false);
            existingUserEditPane.setVisible(false);
            addNewModuleBtn.setVisible(false);
            editComponentPanel.setVisible(false);
            addNewComponentModuleCombo.setVisible(false);
            addNewComponentBtn.setVisible(false);


            //
           loadSimModuleTypeCombobox(controller.fetchModuleTypes(), componentModuleTypeComboBox);
        } catch (IOException ex) {
            Logger.getLogger(AdminSimView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        adminTaskSimulatorUserButtonGroup = new javax.swing.ButtonGroup();
        adminTaskModuleButtonGroup = new javax.swing.ButtonGroup();
        adminTaskComponentBtnGroup = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel6 = new javax.swing.JPanel();
        adminTaskTabPane = new javax.swing.JTabbedPane();
        welcomeTab = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        addremoveTips = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        addNewSimModuleTaskOnSelect1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        addNewSimModuleTaskOnSelect2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        addNewSimModuleTaskOnSelect3 = new javax.swing.JLabel();
        addNewSimModuleTaskOnSelect4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        moduleTypeTab = new javax.swing.JPanel();
        moduleTypeNew = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        newSimModuleTypeNameField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        newSimModuleTypeDesc = new javax.swing.JTextArea();
        addNewBtn = new javax.swing.JButton();
        errorLabeL = new javax.swing.JLabel();
        newCheckBox = new javax.swing.JCheckBox();
        existingCheckBox = new javax.swing.JCheckBox();
        moduleTypeExisting = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        SimModuleTypeList = new javax.swing.JList();
        existingRefresh = new javax.swing.JLabel();
        deleteModuleType = new javax.swing.JLabel();
        loadModuleTypeInfoBtn = new javax.swing.JLabel();
        editPane = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        editPaneModuleTypeId = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        editPaneModuleTypeTypeName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        editPaneModuleTypeDesc = new javax.swing.JTextArea();
        updateBtn = new javax.swing.JButton();
        errorLabel2 = new javax.swing.JLabel();
        noOfModulesLabelTxt = new javax.swing.JLabel();
        userTab = new javax.swing.JPanel();
        usersExistingPanel = new javax.swing.JPanel();
        usersExistingMiniPanel = new javax.swing.JPanel();
        userExistingScrollPane = new javax.swing.JScrollPane();
        existingUsersList = new javax.swing.JList();
        usersExistingRefresh = new javax.swing.JLabel();
        deleteUserExisting = new javax.swing.JLabel();
        loadUserExisting = new javax.swing.JLabel();
        existingUserEditPane = new javax.swing.JPanel();
        editUserFirstNameLabel = new javax.swing.JLabel();
        editUserMiddleNameLabel = new javax.swing.JLabel();
        editUserMiddleNameTxt = new javax.swing.JTextField();
        editUserLastNameLabel = new javax.swing.JLabel();
        updateUserBtn = new javax.swing.JButton();
        userTabErrorLabel = new javax.swing.JLabel();
        editUserFirstNameTxt = new javax.swing.JTextField();
        editUserLastNameTxt = new javax.swing.JTextField();
        editUserUserNameLabel = new javax.swing.JLabel();
        editUserUserNameTxt = new javax.swing.JTextField();
        editUserPassLabel = new javax.swing.JLabel();
        editUserPassTxt = new javax.swing.JPasswordField();
        addNewUserCheckBox = new javax.swing.JCheckBox();
        existingUsersCheckBox = new javax.swing.JCheckBox();
        userAddPane = new javax.swing.JPanel();
        userAddfirstNameLabel = new javax.swing.JLabel();
        userAddMiddleNameLabel = new javax.swing.JLabel();
        userAddMiddleNameTxt = new javax.swing.JTextField();
        userAddLastNameLabel = new javax.swing.JLabel();
        addNewUserBtn = new javax.swing.JButton();
        userAddErrorLabel = new javax.swing.JLabel();
        userAddFirstNameTxt = new javax.swing.JTextField();
        userAddLastNameTxt = new javax.swing.JTextField();
        userAddUserNameLabel = new javax.swing.JLabel();
        userAddUserNameTxt = new javax.swing.JTextField();
        userAddPassLabel = new javax.swing.JLabel();
        userAddPassTxt = new javax.swing.JPasswordField();
        userAddConfirmPassTxt = new javax.swing.JPasswordField();
        userAddConfirmPassLabel = new javax.swing.JLabel();
        clearTextField = new javax.swing.JButton();
        moduleTab = new javax.swing.JPanel();
        addModulePane = new javax.swing.JPanel();
        addNewModuleNameLabel = new javax.swing.JLabel();
        addNewModuleNameTxt = new javax.swing.JTextField();
        addNewModuleDescriptionLabel = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        addNewModuleDescriptionTxt = new javax.swing.JTextArea();
        addNewModuleBtn = new javax.swing.JButton();
        addNewModuleErrorLabel = new javax.swing.JLabel();
        addNewModuleVersionLabel = new javax.swing.JLabel();
        addNewModuleVersionTxt = new javax.swing.JTextField();
        chooseModuleTypeCombo = new javax.swing.JComboBox();
        chooseModuleTypeComboLabel = new javax.swing.JLabel();
        moduleIdTxt = new javax.swing.JTextField();
        modulePane = new javax.swing.JPanel();
        modulesListMiniPane = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        simModuleList = new javax.swing.JList();
        moduleRefresh = new javax.swing.JLabel();
        deleteModule = new javax.swing.JLabel();
        loadModuleInfo = new javax.swing.JLabel();
        editModulePane = new javax.swing.JPanel();
        editModuleIdLabel = new javax.swing.JLabel();
        editModuleIdTxt = new javax.swing.JTextField();
        editModuleNameLabel = new javax.swing.JLabel();
        editModuleVersionTxt = new javax.swing.JTextField();
        editModuleDescriptionLabel = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        editModuleDescriptionTxt = new javax.swing.JTextArea();
        updateModuleBtn = new javax.swing.JButton();
        editPaneErrorLabel = new javax.swing.JLabel();
        editModuleNoOfComponentsTxt = new javax.swing.JTextField();
        editModuleVersionLabel = new javax.swing.JLabel();
        editModuleNoOfComponentsLabel = new javax.swing.JLabel();
        editModuleNameTxt = new javax.swing.JTextField();
        loadModuleTypeCombo = new javax.swing.JComboBox();
        addNewModulesCheckBox = new javax.swing.JCheckBox();
        existingModulesCheckBox = new javax.swing.JCheckBox();
        componentTab = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        editComponentPanel = new javax.swing.JPanel();
        componentNameLabel = new javax.swing.JLabel();
        componentNameTxt = new javax.swing.JTextField();
        componentRawIconLabel = new javax.swing.JLabel();
        componentRawIconPane = new javax.swing.JPanel();
        componentRawIconImage = new javax.swing.JLabel();
        componentDescriptionImagePanel = new javax.swing.JPanel();
        componentDescriptionImage = new javax.swing.JLabel();
        componentDescriptionLabel = new javax.swing.JLabel();
        addNewComponentBtn = new javax.swing.JButton();
        componentDescription = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        componentDescriptionTxt = new javax.swing.JTextArea();
        updateComponentBtn = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        uploadIconImageBtn = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        uploadDescriptionImageBtn = new javax.swing.JButton();
        uploadWiredFrameImageBtn = new javax.swing.JButton();
        uploadSolidImageBtn = new javax.swing.JButton();
        uploadIconImageTxt = new javax.swing.JTextField();
        uploadWiredFrameImageTxt = new javax.swing.JTextField();
        uploadDescriptionIconImageTxt = new javax.swing.JTextField();
        uploadSolidImageTxt = new javax.swing.JTextField();
        addComponentErrorLabel = new javax.swing.JLabel();
        componentPane = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        userExistingScrollPane1 = new javax.swing.JScrollPane();
        simComponenTabList = new javax.swing.JList();
        deleteComponent = new javax.swing.JLabel();
        loadComponentInfo = new javax.swing.JLabel();
        viewExistingCheckBox = new javax.swing.JCheckBox();
        addNewCheckBox = new javax.swing.JCheckBox();
        addNewComponentModuleCombo = new javax.swing.JComboBox();
        ruleTab = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        rulesComponentList = new javax.swing.JList();
        jScrollPane4 = new javax.swing.JScrollPane();
        rulesCandidateComponentList = new javax.swing.JList();
        jScrollPane6 = new javax.swing.JScrollPane();
        rulesSuccessorComponentsList = new javax.swing.JList();
        moveOneBtn = new javax.swing.JButton();
        moveAllBtn = new javax.swing.JButton();
        returnOneBtn = new javax.swing.JButton();
        returnAllBtn = new javax.swing.JButton();
        loadCandidates = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        rulesSelectedComponentList = new javax.swing.JList();
        addNewRulesBtn = new javax.swing.JButton();
        loadCandidates1 = new javax.swing.JLabel();
        addNewRulesBtn1 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        componentId = new javax.swing.JLabel();
        modType = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        artStatus = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        enlarged2dimageLabel = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        descLabel = new javax.swing.JLabel();
        loadAllComponents = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        objtextbox = new javax.swing.JTextField();
        mtltext = new javax.swing.JTextField();
        selObj = new javax.swing.JLabel();
        selMtl = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        imgtext = new javax.swing.JTextField();
        selImg = new javax.swing.JLabel();
        add3d = new javax.swing.JButton();
        butt = new javax.swing.JButton();
        componentModuleTypeComboBox = new javax.swing.JComboBox();
        componentModuleComboBox = new javax.swing.JComboBox();
        jPanel15 = new javax.swing.JPanel();
        addScriptFileCheckBox = new javax.swing.JCheckBox();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        moduleTypeUpdateBtn = new javax.swing.JButton();
        moduleTypeAddBtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1295, 667));

        adminTaskTabPane.setForeground(new java.awt.Color(255, 0, 0));
        adminTaskTabPane.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        adminTaskTabPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminTaskTabPaneMouseClicked(evt);
            }
        });

        welcomeTab.setBackground(new java.awt.Color(255, 255, 255));
        welcomeTab.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel1.setText("Welcome, Admin User:");

        addremoveTips.setBackground(new java.awt.Color(255, 0, 0));
        addremoveTips.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addremoveTips.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/Adminicon.png"))); // NOI18N
        addremoveTips.setText("<HTML><U>Module Types</U></HTML>");

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel2.setText("This Button edits/adds new SimModuleType ");

        addNewSimModuleTaskOnSelect1.setBackground(new java.awt.Color(255, 51, 51));
        addNewSimModuleTaskOnSelect1.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewSimModuleTaskOnSelect1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/addComp.png"))); // NOI18N
        addNewSimModuleTaskOnSelect1.setText("<HTML><U>Sim Modules</U></HTML>");

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel3.setText("This Button edits/adds new SimModule to The App.");

        addNewSimModuleTaskOnSelect2.setBackground(new java.awt.Color(255, 51, 51));
        addNewSimModuleTaskOnSelect2.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewSimModuleTaskOnSelect2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/addmodule.png"))); // NOI18N
        addNewSimModuleTaskOnSelect2.setText("<HTML><U>Sim Components</U></HTML>");

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel4.setText("This Button edits/adds new SimComponent to The App.");

        addNewSimModuleTaskOnSelect3.setBackground(new java.awt.Color(255, 51, 51));
        addNewSimModuleTaskOnSelect3.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewSimModuleTaskOnSelect3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/rules.png"))); // NOI18N
        addNewSimModuleTaskOnSelect3.setText("<HTML><U>Rules</U></HTML>");

        addNewSimModuleTaskOnSelect4.setBackground(new java.awt.Color(255, 51, 51));
        addNewSimModuleTaskOnSelect4.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewSimModuleTaskOnSelect4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/adduser.png"))); // NOI18N
        addNewSimModuleTaskOnSelect4.setText("<HTML><U>Sim User</U></HTML>");

        jLabel5.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel5.setText("This Button adds a new Set of rules to the predecessors and successors.");

        jLabel8.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel8.setText("This Button edits and adds new SimUser");

        javax.swing.GroupLayout welcomeTabLayout = new javax.swing.GroupLayout(welcomeTab);
        welcomeTab.setLayout(welcomeTabLayout);
        welcomeTabLayout.setHorizontalGroup(
            welcomeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(welcomeTabLayout.createSequentialGroup()
                .addGroup(welcomeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(welcomeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addNewSimModuleTaskOnSelect3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addNewSimModuleTaskOnSelect4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addNewSimModuleTaskOnSelect2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addNewSimModuleTaskOnSelect1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addremoveTips, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jLabel3))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel4))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(jLabel5))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jLabel8))
                    .addGroup(welcomeTabLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel2)))
                .addContainerGap(542, Short.MAX_VALUE))
        );
        welcomeTabLayout.setVerticalGroup(
            welcomeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(welcomeTabLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(addremoveTips, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addNewSimModuleTaskOnSelect1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addNewSimModuleTaskOnSelect2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(16, 16, 16)
                .addComponent(addNewSimModuleTaskOnSelect3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(addNewSimModuleTaskOnSelect4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jLabel8)
                .addGap(404, 404, 404))
        );

        adminTaskTabPane.addTab("WELCOME", welcomeTab);

        moduleTypeNew.setBackground(new java.awt.Color(204, 204, 204));

        jLabel6.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        jLabel6.setText("TypeName:");

        newSimModuleTypeNameField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        newSimModuleTypeNameField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newSimModuleTypeNameFieldMouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        jLabel7.setText("Description:");

        newSimModuleTypeDesc.setColumns(10);
        newSimModuleTypeDesc.setLineWrap(true);
        newSimModuleTypeDesc.setRows(5);
        newSimModuleTypeDesc.setWrapStyleWord(true);
        newSimModuleTypeDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newSimModuleTypeDescMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(newSimModuleTypeDesc);

        addNewBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        addNewBtn.setText("ADD NEW");
        addNewBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewBtnMouseClicked(evt);
            }
        });

        errorLabeL.setForeground(new java.awt.Color(0, 153, 0));

        javax.swing.GroupLayout moduleTypeNewLayout = new javax.swing.GroupLayout(moduleTypeNew);
        moduleTypeNew.setLayout(moduleTypeNewLayout);
        moduleTypeNewLayout.setHorizontalGroup(
            moduleTypeNewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTypeNewLayout.createSequentialGroup()
                .addGroup(moduleTypeNewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(moduleTypeNewLayout.createSequentialGroup()
                        .addGap(224, 224, 224)
                        .addComponent(addNewBtn)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, moduleTypeNewLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(moduleTypeNewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(moduleTypeNewLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(errorLabeL, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(moduleTypeNewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(newSimModuleTypeNameField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        moduleTypeNewLayout.setVerticalGroup(
            moduleTypeNewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTypeNewLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(newSimModuleTypeNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(errorLabeL, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addNewBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        buttonGroup1.add(newCheckBox);
        newCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        newCheckBox.setText("New ModuleType?");
        newCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                newCheckBoxItemStateChanged(evt);
            }
        });

        buttonGroup1.add(existingCheckBox);
        existingCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        existingCheckBox.setText("Existing ModuleType");
        existingCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                existingCheckBoxItemStateChanged(evt);
            }
        });

        moduleTypeExisting.setBackground(new java.awt.Color(204, 204, 204));
        moduleTypeExisting.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jLabel9.setText("List Of ModuleTypes");

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        SimModuleTypeList.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        SimModuleTypeList.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        SimModuleTypeList.setModel(listSimModuleTypes);
        SimModuleTypeList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        SimModuleTypeList.setEnabled(false);
        SimModuleTypeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SimModuleTypeListMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(SimModuleTypeList);

        existingRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/refresh.png"))); // NOI18N
        existingRefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                existingRefreshMouseClicked(evt);
            }
        });

        deleteModuleType.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        deleteModuleType.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/delete.png"))); // NOI18N
        deleteModuleType.setText("DELETE");
        deleteModuleType.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteModuleTypeMouseClicked(evt);
            }
        });

        loadModuleTypeInfoBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        loadModuleTypeInfoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/history.png"))); // NOI18N
        loadModuleTypeInfoBtn.setText("LOAD INFO");
        loadModuleTypeInfoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadModuleTypeInfoBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(existingRefresh)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(deleteModuleType, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(loadModuleTypeInfoBtn))))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(existingRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(deleteModuleType)
                    .addComponent(loadModuleTypeInfoBtn))
                .addGap(36, 36, 36))
        );

        editPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Edit Pane", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Trebuchet MS", 1, 12))); // NOI18N

        jLabel11.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jLabel11.setText("MODULETYPE ID:");

        editPaneModuleTypeId.setEditable(false);
        editPaneModuleTypeId.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        editPaneModuleTypeId.setText("****");
        editPaneModuleTypeId.setEnabled(false);

        jLabel12.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jLabel12.setText("TYPENAME:");

        editPaneModuleTypeTypeName.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        editPaneModuleTypeTypeName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editPaneModuleTypeTypeNameMouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jLabel13.setText("DESCRIPTION:");

        editPaneModuleTypeDesc.setColumns(10);
        editPaneModuleTypeDesc.setLineWrap(true);
        editPaneModuleTypeDesc.setRows(5);
        editPaneModuleTypeDesc.setWrapStyleWord(true);
        editPaneModuleTypeDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editPaneModuleTypeDescMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(editPaneModuleTypeDesc);

        updateBtn.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        updateBtn.setText("OK");
        updateBtn.setEnabled(false);
        updateBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateBtnMouseClicked(evt);
            }
        });

        errorLabel2.setForeground(new java.awt.Color(0, 153, 51));

        noOfModulesLabelTxt.setText("No Of Modules");

        javax.swing.GroupLayout editPaneLayout = new javax.swing.GroupLayout(editPane);
        editPane.setLayout(editPaneLayout);
        editPaneLayout.setHorizontalGroup(
            editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editPaneLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(noOfModulesLabelTxt)
                    .addGroup(editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(errorLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11)
                            .addComponent(editPaneModuleTypeId)
                            .addComponent(editPaneModuleTypeTypeName)
                            .addComponent(jLabel13)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editPaneLayout.createSequentialGroup()
                        .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)))
                .addGap(29, 29, 29))
        );
        editPaneLayout.setVerticalGroup(
            editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editPaneLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editPaneModuleTypeId, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editPaneModuleTypeTypeName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGroup(editPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editPaneLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(errorLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(editPaneLayout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(noOfModulesLabelTxt)))
                .addGap(2, 2, 2)
                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );

        javax.swing.GroupLayout moduleTypeExistingLayout = new javax.swing.GroupLayout(moduleTypeExisting);
        moduleTypeExisting.setLayout(moduleTypeExistingLayout);
        moduleTypeExistingLayout.setHorizontalGroup(
            moduleTypeExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTypeExistingLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(moduleTypeExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                .addComponent(editPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        moduleTypeExistingLayout.setVerticalGroup(
            moduleTypeExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTypeExistingLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(moduleTypeExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(editPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout moduleTypeTabLayout = new javax.swing.GroupLayout(moduleTypeTab);
        moduleTypeTab.setLayout(moduleTypeTabLayout);
        moduleTypeTabLayout.setHorizontalGroup(
            moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTypeTabLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moduleTypeNew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(moduleTypeTabLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(newCheckBox)))
                .addGroup(moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(moduleTypeTabLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(moduleTypeExisting, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, moduleTypeTabLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(existingCheckBox)
                        .addGap(271, 271, 271))))
        );
        moduleTypeTabLayout.setVerticalGroup(
            moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, moduleTypeTabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newCheckBox)
                    .addComponent(existingCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(moduleTypeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moduleTypeNew, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(moduleTypeExisting, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(41, 41, 41))
        );

        adminTaskTabPane.addTab("", moduleTypeTab);

        usersExistingPanel.setEnabled(false);

        usersExistingMiniPanel.setBackground(new java.awt.Color(255, 255, 255));
        usersExistingMiniPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "List Of Users", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N

        existingUsersList.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        existingUsersList.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        existingUsersList.setModel(listSimUsers);
        existingUsersList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        existingUsersList.setEnabled(false);
        existingUsersList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                existingUsersListMouseClicked(evt);
            }
        });
        userExistingScrollPane.setViewportView(existingUsersList);

        usersExistingRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/refresh.png"))); // NOI18N
        usersExistingRefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usersExistingRefreshMouseClicked(evt);
            }
        });

        deleteUserExisting.setFont(new java.awt.Font("Trebuchet MS", 1, 10)); // NOI18N
        deleteUserExisting.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/locked24.png"))); // NOI18N
        deleteUserExisting.setText("Disable/Enable");
        deleteUserExisting.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteUserExistingMouseClicked(evt);
            }
        });

        loadUserExisting.setFont(new java.awt.Font("Trebuchet MS", 1, 10)); // NOI18N
        loadUserExisting.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/history.png"))); // NOI18N
        loadUserExisting.setText("LOAD INFO");
        loadUserExisting.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadUserExistingMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout usersExistingMiniPanelLayout = new javax.swing.GroupLayout(usersExistingMiniPanel);
        usersExistingMiniPanel.setLayout(usersExistingMiniPanelLayout);
        usersExistingMiniPanelLayout.setHorizontalGroup(
            usersExistingMiniPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(usersExistingMiniPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(usersExistingMiniPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(usersExistingMiniPanelLayout.createSequentialGroup()
                        .addComponent(deleteUserExisting)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loadUserExisting, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(usersExistingMiniPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(usersExistingRefresh)
                        .addComponent(userExistingScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        usersExistingMiniPanelLayout.setVerticalGroup(
            usersExistingMiniPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(usersExistingMiniPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(usersExistingRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userExistingScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(usersExistingMiniPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loadUserExisting)
                    .addComponent(deleteUserExisting, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        existingUserEditPane.setBackground(new java.awt.Color(204, 204, 204));
        existingUserEditPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Edit Pane", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        editUserFirstNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editUserFirstNameLabel.setText("FIRST NAME:");

        editUserMiddleNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editUserMiddleNameLabel.setText("MIDDLE NAME:");

        editUserMiddleNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editUserLastNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editUserLastNameLabel.setText("LAST NAME:");

        updateUserBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        updateUserBtn.setText("OK");
        updateUserBtn.setEnabled(false);
        updateUserBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateUserBtnMouseClicked(evt);
            }
        });

        userTabErrorLabel.setForeground(new java.awt.Color(0, 153, 51));

        editUserFirstNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editUserLastNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editUserUserNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editUserUserNameLabel.setText("USERNAME:");

        editUserUserNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editUserPassLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editUserPassLabel.setText("PASSWORD:");

        editUserPassTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        javax.swing.GroupLayout existingUserEditPaneLayout = new javax.swing.GroupLayout(existingUserEditPane);
        existingUserEditPane.setLayout(existingUserEditPaneLayout);
        existingUserEditPaneLayout.setHorizontalGroup(
            existingUserEditPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(existingUserEditPaneLayout.createSequentialGroup()
                .addGroup(existingUserEditPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(existingUserEditPaneLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(userTabErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 84, Short.MAX_VALUE))
                    .addGroup(existingUserEditPaneLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(existingUserEditPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editUserPassTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editUserFirstNameTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editUserMiddleNameTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editUserLastNameTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editUserUserNameTxt)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, existingUserEditPaneLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(existingUserEditPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(editUserPassLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(updateUserBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(editUserFirstNameLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(editUserMiddleNameLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(editUserLastNameLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(editUserUserNameLabel, javax.swing.GroupLayout.Alignment.TRAILING))))))
                .addContainerGap())
        );
        existingUserEditPaneLayout.setVerticalGroup(
            existingUserEditPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(existingUserEditPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editUserFirstNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editUserFirstNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editUserMiddleNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editUserMiddleNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editUserLastNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editUserLastNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editUserUserNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editUserUserNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editUserPassLabel)
                .addGap(9, 9, 9)
                .addComponent(editUserPassTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(updateUserBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(userTabErrorLabel)
                .addGap(43, 43, 43))
        );

        javax.swing.GroupLayout usersExistingPanelLayout = new javax.swing.GroupLayout(usersExistingPanel);
        usersExistingPanel.setLayout(usersExistingPanelLayout);
        usersExistingPanelLayout.setHorizontalGroup(
            usersExistingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(usersExistingPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(usersExistingMiniPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(existingUserEditPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(102, Short.MAX_VALUE))
        );
        usersExistingPanelLayout.setVerticalGroup(
            usersExistingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(usersExistingMiniPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(existingUserEditPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        adminTaskSimulatorUserButtonGroup.add(addNewUserCheckBox);
        addNewUserCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewUserCheckBox.setText("Add New User");
        addNewUserCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                addNewUserCheckBoxItemStateChanged(evt);
            }
        });

        adminTaskSimulatorUserButtonGroup.add(existingUsersCheckBox);
        existingUsersCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        existingUsersCheckBox.setText("Existing Users");
        existingUsersCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                existingUsersCheckBoxItemStateChanged(evt);
            }
        });

        userAddPane.setBackground(new java.awt.Color(204, 204, 204));
        userAddPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add User", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        userAddfirstNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddfirstNameLabel.setText("FIRST NAME:");

        userAddMiddleNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddMiddleNameLabel.setText("MIDDLE NAME:");

        userAddMiddleNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddLastNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddLastNameLabel.setText("LAST NAME:");

        addNewUserBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        addNewUserBtn.setText("Add");
        addNewUserBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewUserBtnMouseClicked(evt);
            }
        });

        userAddErrorLabel.setForeground(new java.awt.Color(0, 153, 51));

        userAddFirstNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddLastNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddUserNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddUserNameLabel.setText("USERNAME:");

        userAddUserNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddPassLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddPassLabel.setText("PASSWORD:");

        userAddPassTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddConfirmPassTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        userAddConfirmPassLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        userAddConfirmPassLabel.setText("RETYPE PASSWORD:");

        clearTextField.setFont(new java.awt.Font("Trebuchet MS", 1, 13)); // NOI18N
        clearTextField.setText("Clear");
        clearTextField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearTextFieldMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout userAddPaneLayout = new javax.swing.GroupLayout(userAddPane);
        userAddPane.setLayout(userAddPaneLayout);
        userAddPaneLayout.setHorizontalGroup(
            userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(userAddPaneLayout.createSequentialGroup()
                .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, userAddPaneLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(userAddPassTxt)
                            .addComponent(userAddFirstNameTxt)
                            .addComponent(userAddMiddleNameTxt)
                            .addComponent(userAddLastNameTxt)
                            .addComponent(userAddUserNameTxt, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(userAddPaneLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(userAddfirstNameLabel)
                                    .addComponent(userAddMiddleNameLabel)
                                    .addComponent(userAddLastNameLabel)
                                    .addComponent(userAddUserNameLabel)
                                    .addComponent(userAddPassLabel)
                                    .addComponent(userAddConfirmPassLabel)))))
                    .addGroup(userAddPaneLayout.createSequentialGroup()
                        .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(userAddPaneLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(userAddConfirmPassTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(userAddPaneLayout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(userAddErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(userAddPaneLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(clearTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(addNewUserBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        userAddPaneLayout.setVerticalGroup(
            userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(userAddPaneLayout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(userAddfirstNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddFirstNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(userAddMiddleNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddMiddleNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(userAddLastNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddLastNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(userAddUserNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddUserNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(userAddPassLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddPassTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(userAddConfirmPassLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userAddConfirmPassTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(userAddErrorLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(userAddPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addNewUserBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4))
        );

        javax.swing.GroupLayout userTabLayout = new javax.swing.GroupLayout(userTab);
        userTab.setLayout(userTabLayout);
        userTabLayout.setHorizontalGroup(
            userTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, userTabLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(userAddPane, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usersExistingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(31, 31, 31))
            .addGroup(userTabLayout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(addNewUserCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(existingUsersCheckBox)
                .addGap(332, 332, 332))
        );
        userTabLayout.setVerticalGroup(
            userTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, userTabLayout.createSequentialGroup()
                .addContainerGap(61, Short.MAX_VALUE)
                .addGroup(userTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addNewUserCheckBox)
                    .addComponent(existingUsersCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(userTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(usersExistingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(userAddPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(48, 48, 48))
        );

        adminTaskTabPane.addTab("", userTab);

        addModulePane.setBackground(new java.awt.Color(204, 204, 204));
        addModulePane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add Module", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        addNewModuleNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        addNewModuleNameLabel.setText("Module Name:");

        addNewModuleNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addNewModuleNameTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewModuleNameTxtMouseClicked(evt);
            }
        });

        addNewModuleDescriptionLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        addNewModuleDescriptionLabel.setText("Description:");

        addNewModuleDescriptionTxt.setColumns(10);
        addNewModuleDescriptionTxt.setLineWrap(true);
        addNewModuleDescriptionTxt.setRows(5);
        addNewModuleDescriptionTxt.setWrapStyleWord(true);
        addNewModuleDescriptionTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewModuleDescriptionTxtMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(addNewModuleDescriptionTxt);

        addNewModuleBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        addNewModuleBtn.setText("ADD NEW");
        addNewModuleBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewModuleBtnMouseClicked(evt);
            }
        });

        addNewModuleErrorLabel.setForeground(new java.awt.Color(0, 153, 0));

        addNewModuleVersionLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        addNewModuleVersionLabel.setText("Module Version:");

        addNewModuleVersionTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        addNewModuleVersionTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewModuleVersionTxtMouseClicked(evt);
            }
        });

        chooseModuleTypeCombo.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        chooseModuleTypeCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--Select Module--" }));
        chooseModuleTypeCombo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chooseModuleTypeComboMouseClicked(evt);
            }
        });
        chooseModuleTypeCombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                chooseModuleTypeComboItemStateChanged(evt);
            }
        });

        chooseModuleTypeComboLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        chooseModuleTypeComboLabel.setForeground(new java.awt.Color(51, 0, 204));
        chooseModuleTypeComboLabel.setText("which ModuleType do you want to add this module to?");

        javax.swing.GroupLayout addModulePaneLayout = new javax.swing.GroupLayout(addModulePane);
        addModulePane.setLayout(addModulePaneLayout);
        addModulePaneLayout.setHorizontalGroup(
            addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addModulePaneLayout.createSequentialGroup()
                .addGap(253, 253, 253)
                .addComponent(addNewModuleBtn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(addModulePaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addNewModuleErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(addNewModuleDescriptionLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(addNewModuleVersionTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addNewModuleVersionLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(addNewModuleNameTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addNewModuleNameLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, addModulePaneLayout.createSequentialGroup()
                                .addComponent(chooseModuleTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(moduleIdTxt))
                            .addComponent(chooseModuleTypeComboLabel, javax.swing.GroupLayout.Alignment.LEADING))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addModulePaneLayout.setVerticalGroup(
            addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addModulePaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addNewModuleNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addNewModuleNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addNewModuleVersionLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addNewModuleVersionTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addNewModuleDescriptionLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chooseModuleTypeComboLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(addModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chooseModuleTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(moduleIdTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addNewModuleErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addNewModuleBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        modulePane.setBackground(new java.awt.Color(204, 204, 204));
        modulePane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pre-loaded Modules", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12), new java.awt.Color(0, 0, 0))); // NOI18N

        modulesListMiniPane.setBackground(new java.awt.Color(255, 255, 255));
        modulesListMiniPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "List Of Modules", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        simModuleList.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        simModuleList.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        simModuleList.setModel(listSimModules);
        simModuleList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        simModuleList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                simModuleListMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(simModuleList);

        moduleRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/refresh.png"))); // NOI18N
        moduleRefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moduleRefreshMouseClicked(evt);
            }
        });

        deleteModule.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        deleteModule.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/delete.png"))); // NOI18N
        deleteModule.setText("DELETE");
        deleteModule.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteModuleMouseClicked(evt);
            }
        });

        loadModuleInfo.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        loadModuleInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/history.png"))); // NOI18N
        loadModuleInfo.setText("LOAD INFO");
        loadModuleInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadModuleInfoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout modulesListMiniPaneLayout = new javax.swing.GroupLayout(modulesListMiniPane);
        modulesListMiniPane.setLayout(modulesListMiniPaneLayout);
        modulesListMiniPaneLayout.setHorizontalGroup(
            modulesListMiniPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulesListMiniPaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(modulesListMiniPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(moduleRefresh)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(modulesListMiniPaneLayout.createSequentialGroup()
                        .addComponent(deleteModule, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loadModuleInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25))
        );
        modulesListMiniPaneLayout.setVerticalGroup(
            modulesListMiniPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulesListMiniPaneLayout.createSequentialGroup()
                .addComponent(moduleRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addGroup(modulesListMiniPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteModule, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loadModuleInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        editModulePane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Edit Pane", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        editModuleIdLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editModuleIdLabel.setText("MODULE ID:");

        editModuleIdTxt.setEditable(false);
        editModuleIdTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editModuleNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editModuleNameLabel.setText("MODULE NAME:");

        editModuleVersionTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        editModuleVersionTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editModuleVersionTxtMouseClicked(evt);
            }
        });

        editModuleDescriptionLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editModuleDescriptionLabel.setText("DESCRIPTION:");

        editModuleDescriptionTxt.setColumns(10);
        editModuleDescriptionTxt.setLineWrap(true);
        editModuleDescriptionTxt.setRows(5);
        editModuleDescriptionTxt.setWrapStyleWord(true);
        editModuleDescriptionTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editModuleDescriptionTxtMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(editModuleDescriptionTxt);

        updateModuleBtn.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        updateModuleBtn.setText("OK");
        updateModuleBtn.setFocusPainted(false);
        updateModuleBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateModuleBtnMouseClicked(evt);
            }
        });

        editPaneErrorLabel.setForeground(new java.awt.Color(0, 153, 51));

        editModuleNoOfComponentsTxt.setEditable(false);
        editModuleNoOfComponentsTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        editModuleVersionLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editModuleVersionLabel.setText("MODULE VERSION:");

        editModuleNoOfComponentsLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        editModuleNoOfComponentsLabel.setText("No. Of Components:");

        editModuleNameTxt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        javax.swing.GroupLayout editModulePaneLayout = new javax.swing.GroupLayout(editModulePane);
        editModulePane.setLayout(editModulePaneLayout);
        editModulePaneLayout.setHorizontalGroup(
            editModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editModulePaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(editModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editModulePaneLayout.createSequentialGroup()
                        .addComponent(editPaneErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(217, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editModulePaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(editModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(updateModuleBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(editModuleDescriptionLabel)
                            .addComponent(editModuleVersionLabel)
                            .addComponent(editModuleNameLabel)
                            .addComponent(editModuleIdLabel)
                            .addComponent(editModuleVersionTxt)
                            .addComponent(editModuleIdTxt)
                            .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                            .addComponent(editModuleNameTxt)
                            .addComponent(editModuleNoOfComponentsTxt))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editModulePaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(editModuleNoOfComponentsLabel)
                .addGap(25, 25, 25))
        );
        editModulePaneLayout.setVerticalGroup(
            editModulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editModulePaneLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(editModuleIdLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editModuleIdTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editModuleNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editModuleNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editModuleVersionLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editModuleVersionTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editModuleDescriptionLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editModuleNoOfComponentsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editModuleNoOfComponentsTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editPaneErrorLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 83, Short.MAX_VALUE)
                .addComponent(updateModuleBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        loadModuleTypeCombo.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        loadModuleTypeCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select Module Type" }));
        loadModuleTypeCombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                loadModuleTypeComboItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout modulePaneLayout = new javax.swing.GroupLayout(modulePane);
        modulePane.setLayout(modulePaneLayout);
        modulePaneLayout.setHorizontalGroup(
            modulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulePaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(modulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(modulesListMiniPane, javax.swing.GroupLayout.PREFERRED_SIZE, 237, Short.MAX_VALUE)
                    .addComponent(loadModuleTypeCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editModulePane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        modulePaneLayout.setVerticalGroup(
            modulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulePaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(modulePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(modulePaneLayout.createSequentialGroup()
                        .addComponent(loadModuleTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(modulesListMiniPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(editModulePane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        adminTaskModuleButtonGroup.add(addNewModulesCheckBox);
        addNewModulesCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        addNewModulesCheckBox.setText("Add New Module");
        addNewModulesCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                addNewModulesCheckBoxItemStateChanged(evt);
            }
        });

        adminTaskModuleButtonGroup.add(existingModulesCheckBox);
        existingModulesCheckBox.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        existingModulesCheckBox.setText("Existing Modules");
        existingModulesCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                existingModulesCheckBoxItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout moduleTabLayout = new javax.swing.GroupLayout(moduleTab);
        moduleTab.setLayout(moduleTabLayout);
        moduleTabLayout.setHorizontalGroup(
            moduleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(moduleTabLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(addModulePane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(modulePane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(moduleTabLayout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(addNewModulesCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(existingModulesCheckBox)
                .addGap(264, 264, 264))
        );
        moduleTabLayout.setVerticalGroup(
            moduleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, moduleTabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(moduleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addNewModulesCheckBox)
                    .addComponent(existingModulesCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(moduleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addModulePane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modulePane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        adminTaskTabPane.addTab("", moduleTab);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 306, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        editComponentPanel.setBackground(new java.awt.Color(204, 204, 204));
        editComponentPanel.setAutoscrolls(true);
        editComponentPanel.setPreferredSize(new java.awt.Dimension(611, 595));

        componentNameLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentNameLabel.setText("Component Name:");

        componentRawIconLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentRawIconLabel.setText(" IconImage:");

        componentRawIconPane.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout componentRawIconPaneLayout = new javax.swing.GroupLayout(componentRawIconPane);
        componentRawIconPane.setLayout(componentRawIconPaneLayout);
        componentRawIconPaneLayout.setHorizontalGroup(
            componentRawIconPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(componentRawIconPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(componentRawIconImage, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                .addContainerGap())
        );
        componentRawIconPaneLayout.setVerticalGroup(
            componentRawIconPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, componentRawIconPaneLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(componentRawIconImage, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        componentDescriptionImagePanel.setBackground(new java.awt.Color(204, 204, 204));

        componentDescriptionImage.setBackground(new java.awt.Color(255, 255, 255));
        componentDescriptionImage.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout componentDescriptionImagePanelLayout = new javax.swing.GroupLayout(componentDescriptionImagePanel);
        componentDescriptionImagePanel.setLayout(componentDescriptionImagePanelLayout);
        componentDescriptionImagePanelLayout.setHorizontalGroup(
            componentDescriptionImagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(componentDescriptionImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        componentDescriptionImagePanelLayout.setVerticalGroup(
            componentDescriptionImagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, componentDescriptionImagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(componentDescriptionImage, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                .addContainerGap())
        );

        componentDescriptionLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentDescriptionLabel.setText("DescriptionImage:");

        addNewComponentBtn.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        addNewComponentBtn.setText("Add");
        addNewComponentBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewComponentBtnMouseClicked(evt);
            }
        });

        componentDescription.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentDescription.setText("Component Description:");

        componentDescriptionTxt.setColumns(20);
        componentDescriptionTxt.setRows(5);
        jScrollPane11.setViewportView(componentDescriptionTxt);

        updateComponentBtn.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        updateComponentBtn.setText("Update");
        updateComponentBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateComponentBtnMouseClicked(evt);
            }
        });
        updateComponentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateComponentBtnActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        jLabel16.setText("WiredFrameImage:");

        uploadIconImageBtn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        uploadIconImageBtn.setText("upload");
        uploadIconImageBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadIconImageBtnMouseClicked(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        jLabel19.setText("Solid Image:");

        uploadDescriptionImageBtn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        uploadDescriptionImageBtn.setText("upload");
        uploadDescriptionImageBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadDescriptionImageBtnMouseClicked(evt);
            }
        });

        uploadWiredFrameImageBtn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        uploadWiredFrameImageBtn.setText("upload");
        uploadWiredFrameImageBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadWiredFrameImageBtnMouseClicked(evt);
            }
        });

        uploadSolidImageBtn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        uploadSolidImageBtn.setText("upload");
        uploadSolidImageBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                uploadSolidImageBtnMouseClicked(evt);
            }
        });

        uploadIconImageTxt.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N

        uploadWiredFrameImageTxt.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        uploadWiredFrameImageTxt.setMaximumSize(new java.awt.Dimension(21, 2147483647));

        uploadDescriptionIconImageTxt.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N

        uploadSolidImageTxt.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        uploadSolidImageTxt.setMaximumSize(new java.awt.Dimension(21, 2147483647));

        addComponentErrorLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        addComponentErrorLabel.setForeground(new java.awt.Color(0, 153, 51));

        javax.swing.GroupLayout editComponentPanelLayout = new javax.swing.GroupLayout(editComponentPanel);
        editComponentPanel.setLayout(editComponentPanelLayout);
        editComponentPanelLayout.setHorizontalGroup(
            editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editComponentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(addNewComponentBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updateComponentBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE))
                    .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(componentDescriptionImagePanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, editComponentPanelLayout.createSequentialGroup()
                            .addComponent(componentDescriptionLabel)
                            .addGap(14, 14, 14)
                            .addComponent(uploadDescriptionImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(uploadDescriptionIconImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(uploadWiredFrameImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(uploadSolidImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(uploadWiredFrameImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(uploadSolidImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(editComponentPanelLayout.createSequentialGroup()
                                .addComponent(componentRawIconLabel)
                                .addGap(48, 48, 48)
                                .addComponent(componentRawIconPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(editComponentPanelLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(componentNameLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(componentNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(editComponentPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(uploadIconImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, editComponentPanelLayout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(uploadIconImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(51, 51, 51)
                .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(componentDescription))
                .addContainerGap(195, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editComponentPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addComponentErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(101, 101, 101))
        );
        editComponentPanelLayout.setVerticalGroup(
            editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editComponentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(componentRawIconPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(editComponentPanelLayout.createSequentialGroup()
                                .addComponent(uploadIconImageBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(uploadIconImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(componentNameLabel)
                            .addComponent(componentNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(componentDescription))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(editComponentPanelLayout.createSequentialGroup()
                                .addComponent(componentRawIconLabel)
                                .addGap(61, 61, 61)
                                .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(componentDescriptionLabel)
                                    .addComponent(uploadDescriptionImageBtn)
                                    .addComponent(uploadDescriptionIconImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(componentDescriptionImagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(uploadWiredFrameImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(uploadWiredFrameImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(editComponentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(uploadSolidImageBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(uploadSolidImageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addComponent(addNewComponentBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateComponentBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(306, 306, 306))
                    .addGroup(editComponentPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(addComponentErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(273, 273, 273))))
        );

        componentPane.setBackground(new java.awt.Color(204, 204, 204));

        jLabel17.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel17.setText("Select ModuleType :");

        jLabel18.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jLabel18.setText("Select Module:");

        simComponenTabList.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "List Of Components", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N
        simComponenTabList.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        simComponenTabList.setModel(adminCompTabListModel);
        simComponenTabList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        simComponenTabList.setCellRenderer(new ListRenderer());
        simComponenTabList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                simComponenTabListMouseClicked(evt);
            }
        });
        userExistingScrollPane1.setViewportView(simComponenTabList);

        deleteComponent.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteComponent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/delete.png"))); // NOI18N
        deleteComponent.setText("DELETE");
        deleteComponent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteComponentMouseClicked(evt);
            }
        });

        loadComponentInfo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        loadComponentInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/history.png"))); // NOI18N
        loadComponentInfo.setText("LOAD INFO");
        loadComponentInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadComponentInfoMouseClicked(evt);
            }
        });

        adminTaskComponentBtnGroup.add(viewExistingCheckBox);
        viewExistingCheckBox.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        viewExistingCheckBox.setText("Edit Component");
        viewExistingCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                viewExistingCheckBoxItemStateChanged(evt);
            }
        });

        adminTaskComponentBtnGroup.add(addNewCheckBox);
        addNewCheckBox.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addNewCheckBox.setText("Add Component");
        addNewCheckBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                addNewCheckBoxItemStateChanged(evt);
            }
        });

        addNewComponentModuleCombo.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        addNewComponentModuleCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "------Select Module-------" }));
        addNewComponentModuleCombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                addNewComponentModuleComboItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout componentPaneLayout = new javax.swing.GroupLayout(componentPane);
        componentPane.setLayout(componentPaneLayout);
        componentPaneLayout.setHorizontalGroup(
            componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(componentPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(componentPaneLayout.createSequentialGroup()
                        .addComponent(viewExistingCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addNewCheckBox)
                        .addGap(24, 24, 24))
                    .addGroup(componentPaneLayout.createSequentialGroup()
                        .addGroup(componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addNewComponentModuleCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(componentPaneLayout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addGroup(componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(userExistingScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(componentPaneLayout.createSequentialGroup()
                                        .addComponent(deleteComponent, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(loadComponentInfo)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        componentPaneLayout.setVerticalGroup(
            componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(componentPaneLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(viewExistingCheckBox)
                    .addComponent(addNewCheckBox))
                .addGap(18, 18, 18)
                .addComponent(jLabel17)
                .addGap(34, 34, 34)
                .addComponent(jLabel18)
                .addGap(46, 46, 46)
                .addComponent(addNewComponentModuleCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(userExistingScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(componentPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loadComponentInfo)
                    .addComponent(deleteComponent))
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout componentTabLayout = new javax.swing.GroupLayout(componentTab);
        componentTab.setLayout(componentTabLayout);
        componentTabLayout.setHorizontalGroup(
            componentTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(componentTabLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(componentPane, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(editComponentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 689, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        componentTabLayout.setVerticalGroup(
            componentTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(componentTabLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, componentTabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(componentTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(componentPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editComponentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 795, Short.MAX_VALUE))
                .addContainerGap())
        );

        adminTaskTabPane.addTab("", componentTab);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "SELECTION PANE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jLabel10.setText("Select Component");

        rulesComponentList.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        rulesComponentList.setModel(listSimComponents);
        rulesComponentList.setCellRenderer(new ListRenderer());
        jScrollPane5.setViewportView(rulesComponentList);

        rulesCandidateComponentList.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Candidate Components", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N
        rulesCandidateComponentList.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        rulesCandidateComponentList.setModel(listSimComponentsCandidates);
        rulesCandidateComponentList.setCellRenderer(new ListRenderer());
        jScrollPane4.setViewportView(rulesCandidateComponentList);

        rulesSuccessorComponentsList.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Successors", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12))); // NOI18N
        rulesSuccessorComponentsList.setModel(listSimComponentsSuccessors);
        rulesSuccessorComponentsList.setCellRenderer(new ListRenderer());
        jScrollPane6.setViewportView(rulesSuccessorComponentsList);

        moveOneBtn.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        moveOneBtn.setText("MOVE>");
        moveOneBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moveOneBtnMouseClicked(evt);
            }
        });

        moveAllBtn.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        moveAllBtn.setText("MOVE ALL>>");
        moveAllBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moveAllBtnMouseClicked(evt);
            }
        });

        returnOneBtn.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        returnOneBtn.setText("<RETURN");
        returnOneBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                returnOneBtnMouseClicked(evt);
            }
        });

        returnAllBtn.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        returnAllBtn.setText("<<RETURN ALL");
        returnAllBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                returnAllBtnMouseClicked(evt);
            }
        });

        loadCandidates.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        loadCandidates.setText("LOAD CANDIDATES");
        loadCandidates.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadCandidatesMouseClicked(evt);
            }
        });

        rulesSelectedComponentList.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Selected Component", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12), new java.awt.Color(255, 51, 0))); // NOI18N
        rulesSelectedComponentList.setModel(listSimComponentsSelected);
        rulesSelectedComponentList.setCellRenderer(new ListRenderer());
        jScrollPane10.setViewportView(rulesSelectedComponentList);

        addNewRulesBtn.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        addNewRulesBtn.setText("ADD NEW RULES");
        addNewRulesBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewRulesBtnMouseClicked(evt);
            }
        });

        loadCandidates1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        loadCandidates1.setText("LOAD CANDIDATES");
        loadCandidates1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadCandidates1MouseClicked(evt);
            }
        });

        addNewRulesBtn1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        addNewRulesBtn1.setText("ADD NEW RULES");
        addNewRulesBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewRulesBtn1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(loadCandidates)
                        .addGap(355, 355, 355))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(loadCandidates1)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(moveAllBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(moveOneBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(returnOneBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(returnAllBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(addNewRulesBtn, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(46, 46, 46))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addNewRulesBtn1)
                .addGap(56, 56, 56))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(addNewRulesBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addNewRulesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(173, 173, 173)
                                .addComponent(moveOneBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(moveAllBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(returnOneBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(returnAllBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(loadCandidates1)
                                .addGap(342, 342, 342)
                                .addComponent(loadCandidates))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ruleTabLayout = new javax.swing.GroupLayout(ruleTab);
        ruleTab.setLayout(ruleTabLayout);
        ruleTabLayout.setHorizontalGroup(
            ruleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ruleTabLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 958, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(99, Short.MAX_VALUE))
        );
        ruleTabLayout.setVerticalGroup(
            ruleTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ruleTabLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        adminTaskTabPane.addTab("", ruleTab);

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "SELECT COMPONENT", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jList1.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        jList1.setModel(listAllSimComponentsFor3d);
        jList1.setCellRenderer(new ListRenderer());
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane14.setViewportView(jList1);

        jLabel25.setText("Component Information");

        jLabel26.setText("<HTML><U>ModuleType:</U></HTML>");

        jLabel27.setText("<HTML><U>ModuleName:</U></HTML>");

        jLabel29.setText("<HTML><U>    Unique id:</U></HTML>");

        jLabel30.setText("<HTML><U>Artifact Status:</U></HTML>");

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder("Enlarged 2d Image"));
        jPanel14.setAutoscrolls(true);

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(enlarged2dimageLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(enlarged2dimageLabel)
                .addContainerGap(234, Short.MAX_VALUE))
        );

        jLabel31.setText("<HTML><U>Description:</U></HTML>");

        loadAllComponents.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/refresh.png"))); // NOI18N
        loadAllComponents.setText("<HTML><U>RELOAD COMPONENTS</U></HTML>");
        loadAllComponents.setToolTipText("");
        loadAllComponents.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loadAllComponentsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jLabel25))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel13Layout.createSequentialGroup()
                                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(artStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(679, 679, 679))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(modType, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(componentId, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(descLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(676, 676, 676))))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(loadAllComponents, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(loadAllComponents, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(descLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(componentId, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(modType, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(65, Short.MAX_VALUE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(artStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );

        jLabel32.setText("ADD 3D ARTIFACTS");

        jLabel34.setText("OBJ FILE:");

        jLabel35.setText("MTL FILE:");

        mtltext.setMaximumSize(new java.awt.Dimension(6, 20));

        selObj.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/helpsmall.png"))); // NOI18N
        selObj.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        selObj.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selObjMouseClicked(evt);
            }
        });

        selMtl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/helpsmall.png"))); // NOI18N
        selMtl.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        selMtl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selMtlMouseClicked(evt);
            }
        });

        jLabel38.setText("IMAGE FILES:");

        imgtext.setMaximumSize(new java.awt.Dimension(6, 20));

        selImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/helpsmall.png"))); // NOI18N
        selImg.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        selImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selImgMouseClicked(evt);
            }
        });

        add3d.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/addsmall.png"))); // NOI18N
        add3d.setText("ADD ARTIFACTS");
        add3d.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                add3dMouseClicked(evt);
            }
        });

        butt.setText("jButton1");
        butt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttMouseClicked(evt);
            }
        });
        butt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(jLabel32))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(butt)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(add3d))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel12Layout.createSequentialGroup()
                                            .addComponent(jLabel35)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(mtltext, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel12Layout.createSequentialGroup()
                                            .addComponent(jLabel34)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(objtextbox, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addComponent(jLabel38)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(imgtext, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(selObj)
                                    .addComponent(selMtl)
                                    .addComponent(selImg))))))
                .addContainerGap(191, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jLabel32)
                .addGap(13, 13, 13)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(objtextbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(selObj))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(mtltext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(selMtl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(imgtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(selImg))
                .addGap(46, 46, 46)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add3d)
                    .addComponent(butt))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        adminTaskTabPane.addTab("", jPanel12);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(adminTaskTabPane, javax.swing.GroupLayout.PREFERRED_SIZE, 1090, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(adminTaskTabPane, javax.swing.GroupLayout.PREFERRED_SIZE, 691, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 28, Short.MAX_VALUE))
        );

        componentModuleTypeComboBox.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentModuleTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "------Select ModuleType-----" }));
        componentModuleTypeComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                componentModuleTypeComboBoxItemStateChanged(evt);
            }
        });

        componentModuleComboBox.setFont(new java.awt.Font("Trebuchet MS", 0, 13)); // NOI18N
        componentModuleComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "------Select Module-------" }));
        componentModuleComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                componentModuleComboBoxItemStateChanged(evt);
            }
        });

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder("Add/Run Script"));

        buttonGroup2.add(addScriptFileCheckBox);
        addScriptFileCheckBox.setText("Add Script File");

        jTextField1.setText("jTextField1");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/adminfile.png"))); // NOI18N

        buttonGroup2.add(jCheckBox1);
        jCheckBox1.setSelected(true);
        jCheckBox1.setText("Add SQL Script ");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane15.setViewportView(jTextArea1);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/runscript.png"))); // NOI18N
        jButton2.setText("RUN Script>");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(addScriptFileCheckBox))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jCheckBox1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(0, 10, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(addScriptFileCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addComponent(jCheckBox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        moduleTypeUpdateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/update.png"))); // NOI18N
        moduleTypeUpdateBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                moduleTypeUpdateBtnMouseClicked(evt);
            }
        });

        moduleTypeAddBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/addadmin.png"))); // NOI18N

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/addadmin.png"))); // NOI18N

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/karmelos/ksimulator/2ndbaricon/update.png"))); // NOI18N

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(componentModuleTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(componentModuleComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(moduleTypeUpdateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(moduleTypeAddBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(componentModuleTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(moduleTypeUpdateBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(moduleTypeAddBtn)))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton5))
                            .addComponent(componentModuleComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loadModuleTypeListModel(SimModuleType[] arrayType) {

        for (int i = 0; i < arrayType.length; i++) {

            listSimModuleTypes.addElement(arrayType[i]);
        }
    }

    private void loadSimUserListModel(SimUser[] usersArray) {
        for (int i = 0; i < usersArray.length; i++) {
            listSimUsers.addElement(usersArray[i]);
        }

    }

    private void loadSimModulesListModel(SimModule[] modulesArray) {
        for (int i = 0; i < modulesArray.length; i++) {

            listSimModules.addElement(modulesArray[i]);
        }
    }

    private void loadSimModuleTypeCombobox(SimModuleType[] fetchModuleTypes, JComboBox moduleTypeCombo) {

        if (moduleTypeCombo.getItemCount() == 1) {
            // dont clear just add// reload all the moduleTypes          
            for (int i = 0; i < fetchModuleTypes.length; i++) {
                moduleTypeCombo.addItem(fetchModuleTypes[i]);

            }
        } else {
            //remove all moduleTypes but the first

            for (int i = fetchModuleTypes.length; i > 0; i--) {
                moduleTypeCombo.removeItemAt(i);

            }
            //reload all the moduleTypes  
            for (int i = 0; i < fetchModuleTypes.length; i++) {
                moduleTypeCombo.addItem(fetchModuleTypes[i]);

            }

        }

    }

    private void loadSimModuleCombo(SimModule[] simModule, JComboBox typeSelected) {


        if (typeSelected.getItemCount() > 1) {
            // remove all items but the first
            for (int i = simModule.length; i > 0; i--) {
                typeSelected.removeItemAt(i);

            }
            // add new items
            for (int i = 0; i < simModule.length; i++) {
                typeSelected.addItem(simModule[i]);

            }
        } else {
            // add new items
            for (int i = 0; i < simModule.length; i++) {
                typeSelected.addItem(simModule[i]);

            }
        }

    }

    public void LoadSimComponentsList(List<SimComponent> lst, DefaultListModel listModel) {

        listModel.removeAllElements();
        // add new Elements
        for (int i = 0; i < lst.size(); i++) {
            listModel.addElement(lst.get(i));
        }






    }

    private void updateBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateBtnMouseClicked
        errorLabel2.setVisible(true);
        // Saves Updated SimModuleType
        presentSimModuleType = (SimModuleType) SimModuleTypeList.getSelectedValue();
        SimModuleType edited = new SimModuleType();
        edited.setId(presentSimModuleType.getId());
        edited.setTypeName(editPaneModuleTypeTypeName.getText());
        edited.setDescription(editPaneModuleTypeDesc.getText());
        edited.setModules(presentSimModuleType.getModules());
        controller.mergeObject(edited);
        editPaneModuleTypeTypeName.setText("");
        editPaneModuleTypeDesc.setText("");
        noOfModulesLabelTxt.setText("");
        errorLabel2.setText("Record Updated");
    }//GEN-LAST:event_updateBtnMouseClicked

    private void editPaneModuleTypeDescMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editPaneModuleTypeDescMouseClicked
        errorLabel2.setText("");
    }//GEN-LAST:event_editPaneModuleTypeDescMouseClicked

    private void editPaneModuleTypeTypeNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editPaneModuleTypeTypeNameMouseClicked
        errorLabel2.setText("");
    }//GEN-LAST:event_editPaneModuleTypeTypeNameMouseClicked

    private void loadModuleTypeInfoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadModuleTypeInfoBtnMouseClicked
        editPane.setVisible(true);
        errorLabel2.setText(null);
        presentSimModuleType = (SimModuleType) SimModuleTypeList.getSelectedValue();
        if (SimModuleTypeList.getSelectedValue() != null) {
            editPaneModuleTypeTypeName.setText(presentSimModuleType.getTypeName());
            editPaneModuleTypeDesc.setText(presentSimModuleType.getDescription());
            noOfModulesLabelTxt.setText("Existing No of Modules: " + presentSimModuleType.getModules().size());


        } else {
            JOptionPane.showMessageDialog(this, "you must select a Moduletype first");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_loadModuleTypeInfoBtnMouseClicked

    private void deleteModuleTypeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteModuleTypeMouseClicked
        Object selectedObject = SimModuleTypeList.getSelectedValue();
        listSimModuleTypes.removeElement(selectedObject);
        controller.deleteObject(selectedObject);
        editPaneModuleTypeTypeName.setText(null);
        editPaneModuleTypeDesc.setText(null);
    }//GEN-LAST:event_deleteModuleTypeMouseClicked

    private void existingRefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_existingRefreshMouseClicked

        listSimModuleTypes.removeAllElements();
        // refetch
        loadModuleTypeListModel(controller.fetchModuleTypes());
    }//GEN-LAST:event_existingRefreshMouseClicked

    private void SimModuleTypeListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SimModuleTypeListMouseClicked
        // TODO add your handling code here:
        editPane.setVisible(false);
        errorLabel2.setText(null);
        noOfModulesLabelTxt.setText("");
        JList list = (JList) evt.getSource();
        if (list.getSelectedValue() != null) {
            loadModuleTypeInfoBtn.setVisible(true);
            deleteModuleType.setVisible(true);


        }
    }//GEN-LAST:event_SimModuleTypeListMouseClicked

    private void existingCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_existingCheckBoxItemStateChanged
        if (existingCheckBox.isSelected()) {
            addNewBtn.setEnabled(false);
            updateBtn.setEnabled(true);
            SimModuleTypeList.setEnabled(true);
            editPaneModuleTypeDesc.setEditable(true);
            editPaneModuleTypeTypeName.setEditable(true);
            errorLabeL.setVisible(false);
            errorLabel2.setVisible(false);
        }
    }//GEN-LAST:event_existingCheckBoxItemStateChanged

    private void newCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_newCheckBoxItemStateChanged

        if (newCheckBox.isSelected()) {
            addNewBtn.setEnabled(true);
            updateBtn.setEnabled(false);
            SimModuleTypeList.setEnabled(false);
            editPaneModuleTypeDesc.setEditable(false);
            editPaneModuleTypeTypeName.setEditable(false);
            editPaneModuleTypeTypeName.setText(null);
            editPaneModuleTypeDesc.setText(null);
            errorLabeL.setVisible(false);
            errorLabel2.setVisible(false);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_newCheckBoxItemStateChanged

    private void addNewBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewBtnMouseClicked
        errorLabeL.setVisible(true);
        SimModuleType newSimModuleType = new SimModuleType();
        newSimModuleType.setId(null);
        newSimModuleType.setDescription(newSimModuleTypeDesc.getText());
        newSimModuleType.setTypeName(newSimModuleTypeNameField.getText());
        newSimModuleType.setModules(new ArrayList<SimModule>());
        controller.saveObject(newSimModuleType);
        newSimModuleTypeDesc.setText("");
        newSimModuleTypeNameField.setText("");
        errorLabeL.setText("New SimModuleType Saved");
    }//GEN-LAST:event_addNewBtnMouseClicked

    private void newSimModuleTypeDescMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newSimModuleTypeDescMouseClicked
        errorLabeL.setText("");
    }//GEN-LAST:event_newSimModuleTypeDescMouseClicked

    private void newSimModuleTypeNameFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newSimModuleTypeNameFieldMouseClicked
        errorLabeL.setText("");
    }//GEN-LAST:event_newSimModuleTypeNameFieldMouseClicked

    private void adminTaskTabPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminTaskTabPaneMouseClicked
        
    }//GEN-LAST:event_adminTaskTabPaneMouseClicked

    private void newCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_newCheckBoxActionPerformed

    private void existingUsersListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_existingUsersListMouseClicked
        // when component is selected enable delete and info button
        JList list = (JList) evt.getSource();
        if (list.getSelectedValue() != null) {
            deleteUserExisting.setVisible(true);
            loadUserExisting.setVisible(true);

        }
    }//GEN-LAST:event_existingUsersListMouseClicked

    private void usersExistingRefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usersExistingRefreshMouseClicked
        userTabErrorLabel.setText(null);
        //refresh users list to fetch updated data
        listSimUsers.removeAllElements();//clears the Users list

        loadSimUserListModel(controller.fetchSimUser());//refetch updated users
    }//GEN-LAST:event_usersExistingRefreshMouseClicked

    private void deleteUserExistingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteUserExistingMouseClicked
        //TO-DO enable/disable user from full app access
    }//GEN-LAST:event_deleteUserExistingMouseClicked

    private void loadUserExistingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadUserExistingMouseClicked
        // show edit panel to edit the selected User details
        userTabErrorLabel.setText(null);
        existingUserEditPane.setVisible(true);
        updateUserBtn.setEnabled(true);
        customSetTextFieldEditable(editUserFirstNameTxt);
        customSetTextFieldEditable(editUserLastNameTxt);
        customSetTextFieldEditable(editUserMiddleNameTxt);
        customSetTextFieldEditable(editUserUserNameTxt);
        customSetTextFieldEditable(editUserPassTxt);


        if (existingUsersList.getSelectedValue() != null) {
            presentUsers = (SimUser) existingUsersList.getSelectedValue();
            editUserFirstNameTxt.setText(presentUsers.getFirstName());
            editUserLastNameTxt.setText(presentUsers.getLastName());
            editUserMiddleNameTxt.setText(presentUsers.getUsername());
            editUserUserNameTxt.setText(presentUsers.getUsername());
            editUserPassTxt.setText(presentUsers.getPassword());


        } else {
//            JOptionPane.showMessageDialog(this, "you must select a User first");
            OkOption okop = new OkOption(this, "Select a User");
            okop.setLabel1("you must select a User first");
            okop.showDialog();
        }
    }//GEN-LAST:event_loadUserExistingMouseClicked

    private void updateUserBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateUserBtnMouseClicked
        // Saves Updated SimUsers
        SimUser edited = new SimUser();
        edited.setFirstName(editUserFirstNameTxt.getText());
        edited.setLastName(editUserLastNameTxt.getText());
        edited.setMiddleName(editUserMiddleNameTxt.getText());
        edited.setUsername(editUserUserNameTxt.getText());
        edited.setPassword(controller.passwordHasher(new String(editUserPassTxt.getPassword())));

        controller.mergeObject(edited);
        // clear all textfield/passwor field
        customClearTextField(editUserFirstNameTxt);
        customClearTextField(editUserLastNameTxt);
        customClearTextField(editUserMiddleNameTxt);
        customClearTextField(editUserUserNameTxt);
        customClearTextField(editUserPassTxt);
        userTabErrorLabel.setText("Record Updated");
    }//GEN-LAST:event_updateUserBtnMouseClicked

    private void addNewUserBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewUserBtnMouseClicked
        //sets error label visible
        userAddErrorLabel.setVisible(true);
        //Save New User
        if (!new String(userAddPassTxt.getPassword()).equals(new String(userAddConfirmPassTxt.getPassword()))) {
            userAddErrorLabel.setText("Password does not match");
        } else {
            SimUser addNewSimUser = new SimUser();
            addNewSimUser.setFirstName(userAddFirstNameTxt.getText());
            addNewSimUser.setLastName(userAddLastNameTxt.getText());
            addNewSimUser.setMiddleName(userAddMiddleNameTxt.getText());
            addNewSimUser.setUsername(userAddUserNameTxt.getText());
            addNewSimUser.setPassword(controller.passwordHasher(new String(userAddPassTxt.getPassword())));
            controller.saveObject(addNewSimUser);
            userAddFirstNameTxt.setText("");
            userAddLastNameTxt.setText("");
            userAddMiddleNameTxt.setText("");
            userAddUserNameTxt.setText("");
            userAddPassTxt.setText("");
            userAddPassTxt.setText(null);
            userAddConfirmPassTxt.setText(null);
            userAddErrorLabel.setText("New User Saved");
        }

    }//GEN-LAST:event_addNewUserBtnMouseClicked

    private void addNewModuleNameTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewModuleNameTxtMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_addNewModuleNameTxtMouseClicked

    private void addNewModuleDescriptionTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewModuleDescriptionTxtMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_addNewModuleDescriptionTxtMouseClicked

    private void addNewModuleBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewModuleBtnMouseClicked
        //Save New Module


        if (!moduleIdTxt.getText().equals("")) {
            SimModule addNewSimModule = new SimModule();
            addNewSimModule.setId(null);
            addNewSimModule.setModelName(addNewModuleNameTxt.getText());
            addNewSimModule.setVersionName(addNewModuleVersionTxt.getText());
            addNewSimModule.setDescription(addNewModuleDescriptionTxt.getText());
            addNewSimModule.setModuleType((SimModuleType) chooseModuleTypeCombo.getSelectedItem());
            addNewSimModule.setComponents(new ArrayList<SimComponent>());


            controller.saveObject(addNewSimModule);
            addNewModuleNameTxt.setText("");
            addNewModuleVersionTxt.setText("");
            addNewModuleDescriptionTxt.setText("");


            addNewModuleErrorLabel.setVisible(true);
            addNewModuleErrorLabel.setText("New Module Saved");
            //load module type combo
            loadSimModuleTypeCombobox(controller.fetchModuleTypes(), chooseModuleTypeCombo);
            moduleIdTxt.setText(null);
        } else {
//            JOptionPane.showMessageDialog(null, "select a module type");
            OkOption okop = new OkOption(this, "Select a User");
            okop.setLabel1("Select a amodule type");
            okop.showDialog();

        }
    }//GEN-LAST:event_addNewModuleBtnMouseClicked

    private void addNewModuleVersionTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewModuleVersionTxtMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_addNewModuleVersionTxtMouseClicked

    private void simModuleListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_simModuleListMouseClicked
        // when component is selected enable delete and info button
        editModulePane.setVisible(false);
        editPaneErrorLabel.setVisible(false);
        JList list = (JList) evt.getSource();
        if (list.getSelectedValue() != null) {
            deleteModule.setVisible(true);
            loadModuleInfo.setVisible(true);

        }
    }//GEN-LAST:event_simModuleListMouseClicked

    private void moduleRefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moduleRefreshMouseClicked
    }//GEN-LAST:event_moduleRefreshMouseClicked

    private void deleteModuleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteModuleMouseClicked
        // delete selected user form Users List and Database
        try {
            Object selectedObject = simModuleList.getSelectedValue();
            listSimModules.removeElement(selectedObject);
            controller.deleteObject(selectedObject);
            customClearTextField(editModuleIdTxt);
            customClearTextField(editModuleNoOfComponentsTxt);
            customClearTextField(editModuleVersionTxt);
            editModuleDescriptionTxt.setText(null);

            editModulePane.setVisible(false);
        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(null, "deletion error: Module has SimComponent added to it, delete components first before deleting the module");
       OkOption okop = new OkOption(this, null);
            okop.setLabel1("deletion error: Module has SimComponent added to it, delete components first before deleting the module");
      okop.showDialog();
        }
    }//GEN-LAST:event_deleteModuleMouseClicked

    private void loadModuleInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadModuleInfoMouseClicked
        editModulePane.setVisible(true);
        if (simModuleList.getSelectedValue() != null) {

            presentModule = (SimModule) simModuleList.getSelectedValue();
            editModuleIdTxt.setText(presentModule.getId().toString());
            editModuleNameTxt.setText(presentModule.getModelName());
            editModuleVersionTxt.setText(presentModule.getVersionName());
            editModuleDescriptionTxt.setText(presentModule.getDescription());
            editModuleNoOfComponentsTxt.setText("" + presentModule.getComponents().size());



        } else {
//            JOptionPane.showMessageDialog(this, "you must select a Module first");
            
            OkOption okop = new OkOption(this, null);
            okop.setLabel1("you must select a Module first");
      okop.showDialog();
            editModulePane.setVisible(false);
        }
    }//GEN-LAST:event_loadModuleInfoMouseClicked

    private void editModuleVersionTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editModuleVersionTxtMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_editModuleVersionTxtMouseClicked

    private void editModuleDescriptionTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editModuleDescriptionTxtMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_editModuleDescriptionTxtMouseClicked

    private void updateModuleBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateModuleBtnMouseClicked

        editPaneErrorLabel.setVisible(true);
        // Saves Updated SimModuleType
        presentModule = (SimModule) simModuleList.getSelectedValue();
        presentModule.setDescription(editModuleDescriptionTxt.getText());
        presentModule.setModelName(editModuleNameTxt.getText());
        presentModule.setVersionName(editModuleVersionTxt.getText());
        presentModule.setId(presentModule.getId());
        presentModule.setComponents(presentModule.getComponents());
        presentModule.setModuleType(presentModule.getModuleType());
        controller.mergeObject(presentModule);
        editPaneErrorLabel.setText("Record Updated");

    }//GEN-LAST:event_updateModuleBtnMouseClicked

    private void componentModuleTypeComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_componentModuleTypeComboBoxItemStateChanged
        // load module combo box


        JComboBox temp = (JComboBox) evt.getSource();

        int indexselected = temp.getSelectedIndex();


        if (indexselected > 0) {

            SimModuleType typeSelected = (SimModuleType) temp.getSelectedItem();
            loadSimModuleCombo(controller.fetchModules(typeSelected.getId()), componentModuleComboBox);
            loadSimModuleCombo(controller.fetchModules(typeSelected.getId()), addNewComponentModuleCombo);
        }
    }//GEN-LAST:event_componentModuleTypeComboBoxItemStateChanged

    private void componentModuleComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_componentModuleComboBoxItemStateChanged
        // load simComponent list in ComponentAmin tab
        if (componentModuleComboBox.getSelectedIndex() > 0) {
            //get Component List
            SimModule stemp = (SimModule) componentModuleComboBox.getSelectedItem();
            List<SimComponent> compTemp = temporaryList = stemp.getComponents();
            LoadSimComponentsList(compTemp,listSimComponents );

        }
    }//GEN-LAST:event_componentModuleComboBoxItemStateChanged

    private void loadComponentInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadComponentInfoMouseClicked

        //set the edit panel visible to view info and perform edit operation
        addComponentErrorLabel.setText(null);
        addNewComponentBtn.setVisible(false);
        updateComponentBtn.setVisible(true);
        uploadIconImageBtn.setText("change");
        uploadDescriptionImageBtn.setText("change");
        uploadWiredFrameImageBtn.setText("change");
        uploadSolidImageBtn.setText("change");
       


        if (simComponenTabList.getSelectedValue() != null) {
            loadComponentInfo.setVisible(true);
            deleteComponent.setVisible(true);
            updateComponentBtn.setVisible(true);
            editComponentPanel.setVisible(true);
            selectedValue = (SimComponent) simComponenTabList.getSelectedValue();



            componentNameTxt.setText(selectedValue.getComponentName());

            componentDescriptionTxt.setText(selectedValue.getDescription());

            try {
                uploadIconImageTxt.setText(null);
                uploadDescriptionIconImageTxt.setText(null);
                uploadSolidImageTxt.setText(null);
                uploadWiredFrameImageTxt.setText(null);

                componentDescriptionImage.setIcon(selectedValue.getDescriptionIconImage());
                componentRawIconImage.setIcon(selectedValue.getIconImage());


            } catch (IOException ex) {
                Logger.getLogger(AdminSimView.class.getName()).log(Level.SEVERE, null, ex);
            }


        } else {
//            JOptionPane.showMessageDialog(this, "you must select a User first");
            OkOption op = new OkOption(this, null);
            op.setLabel1("you must select a User first");
            op.showDialog();
        }
    }//GEN-LAST:event_loadComponentInfoMouseClicked

    private void deleteComponentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteComponentMouseClicked
        // delete component
        selectedValue = (SimComponent) simComponenTabList.getSelectedValue();
        selectedValue.getComponentName();
        selectedValue.getDescription();
        try {
            selectedValue.getDescriptionIconImage();
            selectedValue.getIconImage();
            selectedValue.getWireframeImage();
            selectedValue.getRawIconImage();

        } catch (IOException ex) {
            Logger.getLogger(AdminSimView.class.getName()).log(Level.SEVERE, null, ex);
        }
        selectedValue.getId();
        selectedValue.getId();
        controller.deleteObject(selectedValue);

    }//GEN-LAST:event_deleteComponentMouseClicked

    private void simComponenTabListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_simComponenTabListMouseClicked
        // when component is selected enable delete and info button
        addComponentErrorLabel.setText(null);

        JList list = (JList) evt.getSource();
        if (list.getSelectedValue() != null) {
            deleteComponent.setVisible(true);
            loadComponentInfo.setVisible(true);

        }
    }//GEN-LAST:event_simComponenTabListMouseClicked

    private void addNewUserCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_addNewUserCheckBoxItemStateChanged
        if (addNewUserCheckBox.isSelected()) {

            addNewUserBtn.setVisible(true);
            clearTextField.setVisible(true);
            updateUserBtn.setEnabled(false);
            existingUsersList.setEnabled(false);
            editUserFirstNameTxt.setEditable(false);
            editUserFirstNameTxt.setText(null);
            editUserLastNameTxt.setEditable(false);
            editUserLastNameTxt.setText(null);
            editUserMiddleNameTxt.setEditable(false);
            editUserMiddleNameTxt.setText(null);
            editUserUserNameTxt.setEditable(false);
            editUserUserNameTxt.setText(null);
            editUserPassTxt.setText(null);
            editUserPassTxt.setEditable(false);
            deleteUserExisting.setVisible(false);
            loadUserExisting.setVisible(false);
            existingUserEditPane.setVisible(false);
            userTabErrorLabel.setText(null);
            userAddErrorLabel.setText(null);
            addNewComponentModuleCombo.setVisible(false);

        }
    }//GEN-LAST:event_addNewUserCheckBoxItemStateChanged

    private void existingUsersCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_existingUsersCheckBoxItemStateChanged
        // TODO add your handling code here:
        existingUsersList.setEnabled(true);
        usersExistingPanel.setVisible(true);
        addNewUserBtn.setVisible(false);
        clearTextField.setVisible(false);
        userTabErrorLabel.setText(null);
        userAddErrorLabel.setText(null);

    }//GEN-LAST:event_existingUsersCheckBoxItemStateChanged

    private void clearTextFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearTextFieldMouseClicked
        // clear all textfield/passwor field
        customClearTextField(userAddFirstNameTxt);
        customClearTextField(userAddLastNameTxt);
        customClearTextField(userAddMiddleNameTxt);
        customClearTextField(userAddUserNameTxt);
        userAddPassTxt.setText(null);
        userAddConfirmPassTxt.setText(null);
        userAddErrorLabel.setVisible(false);

    }//GEN-LAST:event_clearTextFieldMouseClicked

    private void addNewModulesCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_addNewModulesCheckBoxItemStateChanged
        //enable components
        addNewModuleBtn.setVisible(true);
        chooseModuleTypeCombo.setEnabled(true);
        moduleIdTxt.setVisible(true);
        addNewModuleErrorLabel.setVisible(false);


        //set components of the existing/edit panel invisible/uneditable
        deleteModule.setVisible(false);
        loadModuleInfo.setVisible(false);
        editModulePane.setVisible(false);
        simModuleList.setEnabled(false);
        loadModuleTypeCombo.setEnabled(false);

        //clear modules list
        listSimModules.clear();

        //load module type combo
        loadSimModuleTypeCombobox(controller.fetchModuleTypes(), chooseModuleTypeCombo);
    }//GEN-LAST:event_addNewModulesCheckBoxItemStateChanged

    private void existingModulesCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_existingModulesCheckBoxItemStateChanged

        //clear module list
        listSimModules.clear();
        //disable components in the  add new module panel
        addNewModuleBtn.setVisible(false);
        moduleIdTxt.setText(null);
        addNewModuleErrorLabel.setVisible(false);
        editPaneErrorLabel.setVisible(false);

        chooseModuleTypeCombo.setEnabled(false);
        //enable components
        simModuleList.setEnabled(true);
        loadModuleTypeCombo.setEnabled(true);


        //load modules combo box
        loadSimModuleTypeCombobox(controller.fetchModuleTypes(), loadModuleTypeCombo);
    }//GEN-LAST:event_existingModulesCheckBoxItemStateChanged

    private void loadModuleTypeComboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_loadModuleTypeComboItemStateChanged

        editModulePane.setVisible(false);

        // load module combo box
        JComboBox temp = (JComboBox) evt.getSource();
        int indexselected = temp.getSelectedIndex();
        if (indexselected > 0) {
            listSimModules.clear();
            SimModuleType tempSimModuleType = (SimModuleType) loadModuleTypeCombo.getSelectedItem();
            SimModule[] tempSimModule = controller.fetchModules((long) tempSimModuleType.getId());
            for (int i = 0; i < tempSimModule.length; i++) {

                listSimModules.addElement(tempSimModule[i]);
            }
        }
    }//GEN-LAST:event_loadModuleTypeComboItemStateChanged

    private void chooseModuleTypeComboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_chooseModuleTypeComboItemStateChanged
        // load module combo box 

        JComboBox temp = (JComboBox) evt.getSource();
        int indexselected = temp.getSelectedIndex();
        if (indexselected > 0) {
            SimModuleType smt = (SimModuleType) chooseModuleTypeCombo.getSelectedItem();

            moduleIdTxt.setText(smt.getId().toString());
        }

    }//GEN-LAST:event_chooseModuleTypeComboItemStateChanged

    private void chooseModuleTypeComboMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chooseModuleTypeComboMouseClicked
        moduleIdTxt.setVisible(true);
    }//GEN-LAST:event_chooseModuleTypeComboMouseClicked

    private void loadCandidatesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadCandidatesMouseClicked
        listSimComponentsSelected.removeAllElements();

        if (!rulesComponentList.isSelectionEmpty()) {
            listSimComponentsCandidates.removeAllElements();
            selectedValue = (SimComponent) rulesComponentList.getSelectedValue();
            // retrieve other Component appart from selected Componennt
            int selectedValuePosition = temporaryList.indexOf(selectedValue);
            // add to starSelected
            listSimComponentsSelected.addElement(selectedValue);
            //iterate remaining tempList          
            for (int i = 0; i < temporaryList.size(); i++) {
                // add to candidate List
                if (i != selectedValuePosition) {
                    listSimComponentsCandidates.addElement(temporaryList.get(i));
                }

            }
        }
    }//GEN-LAST:event_loadCandidatesMouseClicked

    private void moveOneBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moveOneBtnMouseClicked
        if (!rulesCandidateComponentList.isSelectionEmpty()) {
            SimComponent selectedValue = (SimComponent) rulesCandidateComponentList.getSelectedValue();
            listSimComponentsCandidates.removeElement(selectedValue);
            listSimComponentsSuccessors.addElement(selectedValue);
        } else {
//            JOptionPane.showMessageDialog(this, "You Have Selected No Candidate Component!!");
            OkOption ok = new OkOption(this, null);
            ok.setLabel1("You Have Selected No Candidate Component!!");
            ok.showDialog();
        }
    }//GEN-LAST:event_moveOneBtnMouseClicked

    private void moveAllBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moveAllBtnMouseClicked
        for (int i = 0; i < listSimComponentsCandidates.size(); i++) {
            listSimComponentsSuccessors.addElement(listSimComponentsCandidates.getElementAt(i));

        }
        listSimComponentsCandidates.removeAllElements();
    }//GEN-LAST:event_moveAllBtnMouseClicked

    private void returnOneBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_returnOneBtnMouseClicked
        if (!rulesSuccessorComponentsList.isSelectionEmpty()) {
            SimComponent selectedValue = (SimComponent) rulesSuccessorComponentsList.getSelectedValue();

            listSimComponentsCandidates.addElement(selectedValue);
            listSimComponentsSuccessors.removeElement(selectedValue);


        } else {
//            JOptionPane.showMessageDialog(this, "You Have Selected No Successor Component!!");
            OkOption ok = new OkOption(this, null);
            ok.setLabel1("You Have Selected No Successor Component!!!");
            ok.showDialog();
        }
    }//GEN-LAST:event_returnOneBtnMouseClicked

    private void returnAllBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_returnAllBtnMouseClicked
        for (int i = 0; i < listSimComponentsSuccessors.size(); i++) {
            listSimComponentsCandidates.addElement(listSimComponentsSuccessors.getElementAt(i));

        }
        listSimComponentsSuccessors.removeAllElements();
    }//GEN-LAST:event_returnAllBtnMouseClicked

    private void addNewRulesBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewRulesBtnMouseClicked
        SimComponent tempComponent = (SimComponent) listSimComponentsSelected.get(0);

        List<SimComponent> listed = new LinkedList();
        for (int i = 0; i < listSimComponentsSuccessors.getSize(); i++) {
            listed.add((SimComponent) listSimComponentsSuccessors.get(i));

        }
        //convert a List Collection to a set and Persist
        tempComponent.setPersistentSuccessors(listed);
        controller.mergeObject(tempComponent);
        //clear all listmodels for next
        listSimComponentsSelected.removeAllElements();
        listSimComponentsSuccessors.removeAllElements();
        listSimComponentsCandidates.removeAllElements();
    }//GEN-LAST:event_addNewRulesBtnMouseClicked

    private void addNewComponentBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewComponentBtnMouseClicked
        addNewModuleErrorLabel.setVisible(false);
        // add new Sim Component
        File imageIconToByte = new File(uploadIconImageTxt.getText());
        File solidImageToByte = new File(uploadSolidImageTxt.getText());
        File wiredFrameImageToByte = new File(uploadWiredFrameImageTxt.getText());
        File descriptionIconToByte = new File(uploadDescriptionIconImageTxt.getText());
       
        try {
            byte[] iconImage = readFileToByte(imageIconToByte);
            byte[] solidImage = readFileToByte(solidImageToByte);
            byte[] descImage = readFileToByte(descriptionIconToByte);
            byte[] wiredImage = readFileToByte(wiredFrameImageToByte);
          
            
            SimComponent addNewComp = new SimComponent();
            SimModule addComponentModule = (SimModule) addNewComponentModuleCombo.getSelectedItem();
            addNewComp.setId(null);
            addNewComp.setComponentName(componentNameTxt.getText());
            addNewComp.setDescription(componentDescriptionTxt.getText());
            addNewComp.setModule(addComponentModule);
            addNewComp.setRawIconImage(iconImage);
            addNewComp.setRawSolidImage(solidImage);
            addNewComp.setRawWireframeImage(wiredImage);
            addNewComp.setRawDescriptionimage(descImage);


            if (addComponentModule.getComponents() == null) {
                addComponentModule.setComponents(new ArrayList<SimComponent>());
            }
            addComponentModule.getComponents().add(addNewComp);

            controller.saveObject(addNewComp);

            //clear fields
            addComponentErrorLabel.setText("New component Saved Successfully");
            addNewComponentBtn.setVisible(true);
            updateComponentBtn.setVisible(false);

            adminCompTabListModel.removeAllElements();
            editComponentPanel.setVisible(true);
            addNewComponentModuleCombo.setVisible(true);
            componentModuleComboBox.setVisible(false);

            loadComponentInfo.setVisible(false);

            customClearTextField(componentNameTxt);

            customClearTextField(uploadIconImageTxt);
            customClearTextField(uploadSolidImageTxt);
            customClearTextField(uploadWiredFrameImageTxt);
            customClearTextField(uploadDescriptionIconImageTxt);
            componentDescriptionTxt.setText(null);
            componentRawIconImage.setIcon(null);
            componentDescriptionImage.setIcon(null);

            // load moduletype combo box
            componentModuleTypeComboBox.removeAllItems();
            SimModuleType[] moduleTypes = controller.fetchModuleTypes();


            componentModuleTypeComboBox.setEnabled(true);
            componentModuleTypeComboBox.addItem("Select ModuleType");
            for (int i = 0; i < moduleTypes.length; i++) {
                componentModuleTypeComboBox.addItem(moduleTypes[i]);
            }

        } catch (IOException ex) {

//            JOptionPane.showMessageDialog(null, "error:  " + ex);
            OkOption ok = new OkOption(this, null);
            ok.setLabel1("Error");
            ok.showDialog();
        }

        // Saves Updated SimModules


        //userTabErrorLabel.setText("Record Updated");



    }//GEN-LAST:event_addNewComponentBtnMouseClicked

    private void updateComponentBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateComponentBtnMouseClicked


        try {

            selectedValue = (SimComponent) simComponenTabList.getSelectedValue();


            selectedValue.setComponentName(componentNameTxt.getText());

            selectedValue.setDescription(componentDescriptionTxt.getText());

            selectedValue.setModule(selectedValue.getModule());

            //update Icon image data
            if (!uploadIconImageTxt.getText().isEmpty()) {
                File imageIconToByte = new File(uploadIconImageTxt.getText());
                byte[] iconImage = readFileToByte(imageIconToByte);
                selectedValue.setRawIconImage(iconImage);
            } else {
                selectedValue.setRawIconImage(selectedValue.getRawIconImage());

            }

            //update Solid image data
            if (!uploadSolidImageTxt.getText().isEmpty()) {
                File solidImageToByte = new File(uploadSolidImageTxt.getText());
                byte[] solidImage = readFileToByte(solidImageToByte);
                selectedValue.setRawSolidImage(solidImage);
            } else {
                selectedValue.setRawSolidImage(selectedValue.getRawSolidImage());
            }

            //update wired image data
            if (!uploadWiredFrameImageTxt.getText().isEmpty()) {
                File wiredFrameImageToByte = new File(uploadWiredFrameImageTxt.getText());
                byte[] wiredImage = readFileToByte(wiredFrameImageToByte);
                selectedValue.setRawWireframeImage(wiredImage);
            } else {
                selectedValue.setRawWireframeImage(selectedValue.getRawWireframeImage());
            }

            //update description image data
            if (!uploadDescriptionIconImageTxt.getText().isEmpty()) {
                File descriptionIconToByte = new File(uploadDescriptionIconImageTxt.getText());
                byte[] descImage = readFileToByte(descriptionIconToByte);
                selectedValue.setRawDescriptionimage(descImage);
            } else {
                selectedValue.setRawDescriptionimage(selectedValue.getRawDescriptionimage());
            }

            //update 3 d image back image data


            selectedValue.setId(selectedValue.getId());

            selectedValue.setOverlayOrder(selectedValue.getOverlayOrder());


            controller.mergeObject(selectedValue);
            addComponentErrorLabel.setVisible(true);
            addComponentErrorLabel.setText("Update successful");

            customClearTextField(componentNameTxt);

            customClearTextField(uploadIconImageTxt);
            customClearTextField(uploadSolidImageTxt);
            customClearTextField(uploadWiredFrameImageTxt);
            customClearTextField(uploadDescriptionIconImageTxt);
          

            componentDescriptionTxt.setText(null);
      
            componentRawIconImage.setIcon(null);
            componentDescriptionImage.setIcon(null);

        } catch (IOException ex) {

//            JOptionPane.showMessageDialog(null, "error:  " + ex);
            OkOption ok = new OkOption(this, null);
            ok.setLabel1("Error");
            ok.showDialog();
        }


        // Saves Updated SimModules


        //userTabErrorLabel.setText("Record Updated");
    }//GEN-LAST:event_updateComponentBtnMouseClicked

    private void uploadIconImageBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadIconImageBtnMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose Your File");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        //select  the file 
        int returnval = filechooser.showOpenDialog(this);
        if (returnval == JFileChooser.APPROVE_OPTION) {
            File file = filechooser.getSelectedFile();
            BufferedImage bi;
            try {   //display the image in jlabel
                bi = ImageIO.read(file);
                componentRawIconImage.setIcon(new ImageIcon(bi));
                uploadIconImageTxt.setText(file.getAbsolutePath());
                updateComponentBtn.setVisible(true);

            } catch (IOException e) {
            }
            this.pack();
        }
    }//GEN-LAST:event_uploadIconImageBtnMouseClicked

    private void uploadDescriptionImageBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadDescriptionImageBtnMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose Your File");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        //select  the file 
        int returnval = filechooser.showOpenDialog(this);
        if (returnval == JFileChooser.APPROVE_OPTION) {
            File file = filechooser.getSelectedFile();
            BufferedImage bi;
            try {   //display the image in jlabel
                bi = ImageIO.read(file);
                componentDescriptionImage.setIcon(new ImageIcon(bi));
                uploadDescriptionIconImageTxt.setText(file.getAbsolutePath());
            } catch (IOException e) {
            }
            this.pack();
        }
    }//GEN-LAST:event_uploadDescriptionImageBtnMouseClicked

    private void uploadWiredFrameImageBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadWiredFrameImageBtnMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose Your File");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        //select  the file 
        int returnval = filechooser.showOpenDialog(this);
        if (returnval == JFileChooser.APPROVE_OPTION) {
            File file = filechooser.getSelectedFile();
            BufferedImage bi;
            try {   //display the image in jlabel
                bi = ImageIO.read(file);
                //componentRawIconImage.setIcon(new ImageIcon(bi));
                uploadWiredFrameImageTxt.setText(file.getAbsolutePath());
            } catch (IOException e) {
            }
            this.pack();
        }
    }//GEN-LAST:event_uploadWiredFrameImageBtnMouseClicked

    private void uploadSolidImageBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadSolidImageBtnMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose Your File");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        //select  the file 
        int returnval = filechooser.showOpenDialog(this);
        if (returnval == JFileChooser.APPROVE_OPTION) {
            File file = filechooser.getSelectedFile();
            BufferedImage bi;
            try {   //display the image in jlabel
                bi = ImageIO.read(file);
                //componentRawIconImage.setIcon(new ImageIcon(bi));
                uploadSolidImageTxt.setText(file.getAbsolutePath());
            } catch (IOException e) {
            }
            this.pack();
        }
    }//GEN-LAST:event_uploadSolidImageBtnMouseClicked

    private void addNewComponentModuleComboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_addNewComponentModuleComboItemStateChanged
//hide add component combo box

        JComboBox temp = (JComboBox) evt.getSource();
        int indexselected = temp.getSelectedIndex();
        if (indexselected > 0) {
            SimModule sm = (SimModule) addNewComponentModuleCombo.getSelectedItem();


        }

    }//GEN-LAST:event_addNewComponentModuleComboItemStateChanged

    private void viewExistingCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_viewExistingCheckBoxItemStateChanged
        addComponentErrorLabel.setText(null);
        addNewComponentModuleCombo.setVisible(false);
        componentModuleComboBox.setVisible(true);
        updateComponentBtn.setVisible(true);
        simComponenTabList.setVisible(true);

        //hide editing panel
        editComponentPanel.setVisible(false);
        // load moduletype combo box
        componentModuleTypeComboBox.removeAllItems();
        componentModuleComboBox.removeAllItems();
        addNewComponentModuleCombo.removeAllItems();
        SimModuleType[] moduleTypes = controller.fetchModuleTypes();
        componentModuleComboBox.addItem("Select Module");
        addNewComponentModuleCombo.addItem("Select Module");
        componentModuleTypeComboBox.addItem("Select ModuleType");
        componentModuleTypeComboBox.setEnabled(true);
        for (int i = 0; i < moduleTypes.length; i++) {
            componentModuleTypeComboBox.addItem(moduleTypes[i]);
        }
    }//GEN-LAST:event_viewExistingCheckBoxItemStateChanged

    private void addNewCheckBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_addNewCheckBoxItemStateChanged

        //load add new 
        updateComponentBtn.setVisible(false);
        uploadIconImageBtn.setText("upload");
        uploadDescriptionImageBtn.setText("upload");
        uploadWiredFrameImageBtn.setText("upload");
        uploadSolidImageBtn.setText("upload");
       


        addNewComponentBtn.setVisible(true);

        addComponentErrorLabel.setText(null);
        adminCompTabListModel.removeAllElements();
        editComponentPanel.setVisible(true);
        addNewComponentModuleCombo.setVisible(true);
        componentModuleComboBox.setVisible(false);
        deleteComponent.setVisible(false);
        loadComponentInfo.setVisible(false);

        customClearTextField(componentNameTxt);

        customClearTextField(uploadIconImageTxt);
        customClearTextField(uploadSolidImageTxt);
        customClearTextField(uploadWiredFrameImageTxt);
        customClearTextField(uploadDescriptionIconImageTxt);
       
        componentDescriptionTxt.setText(null);
       
        componentRawIconImage.setIcon(null);
        componentDescriptionImage.setIcon(null);
        simComponenTabList.setVisible(false);

        // load moduletype combo box
        componentModuleTypeComboBox.removeAllItems();
        SimModuleType[] moduleTypes = controller.fetchModuleTypes();


        componentModuleTypeComboBox.setEnabled(true);
        componentModuleTypeComboBox.addItem("Select ModuleType");
        for (int i = 0; i < moduleTypes.length; i++) {
            componentModuleTypeComboBox.addItem(moduleTypes[i]);
        }
    }//GEN-LAST:event_addNewCheckBoxItemStateChanged

    private void loadAllComponentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadAllComponentsMouseClicked
        listAllSimComponentsFor3d.removeAllElements();
        List<SimComponent> retrieveAllSimComponent = controller.retrieveAllSimComponent();
        for (SimComponent s : retrieveAllSimComponent) {
            listAllSimComponentsFor3d.addElement(s);

        }
    }//GEN-LAST:event_loadAllComponentsMouseClicked

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        JList src = (JList) evt.getSource();
        SimComponent selected = (SimComponent) src.getSelectedValue();
        descLabel.setText(selected.getDescription());
        componentId.setText("" + selected.getId());
        jLabel33.setText(selected.getModule().getModelName() + "version" + selected.getModule().getVersionName());
        modType.setText(selected.getModule().getModuleType().getTypeName());
        File artObjFile = new File("KSim3DResource" + "\\obj_" + selected.getId() + ".obj");
        if (artObjFile.exists()) {
            artStatus.setForeground(Color.green);
            artStatus.setText("3d artifacts available");
        } else {
            artStatus.setForeground(Color.red);
            artStatus.setText("3d artifacts UNavailable");
        }
        try {
            enlarged2dimageLabel.setIcon(selected.getDescriptionIconImage());
        } catch (IOException ex) {
            Logger.getLogger(AdminSimView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jList1MouseClicked

    private void add3dMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_add3dMouseClicked
        if (artStatus.getText().equalsIgnoreCase("3d artifacts available")) {
            YesNoOption yesno = new YesNoOption(this, null);
            yesno.setLabel1("Are You Sure You Want to overwrite?");
            boolean response = yesno.showDialog();
//            int response = JOptionPane.showConfirmDialog(this, "Are You Sure You Want to overwrite?", null, JOptionPane.YES_NO_OPTION);
            if (response) {
               writeAllFiles(filebyte, outfile);
                //Saheed put in file chooser alternatives here
            }
        } else if (artStatus.getText().equalsIgnoreCase(null)) {
//            JOptionPane.showMessageDialog(this, "You havent selected Component Yet");
            OkOption ok = new OkOption(this, null);
            ok.setLabel1("You havent selected Component Yet");
            ok.showDialog();

        }


        // TODO add your handling code here:
    }//GEN-LAST:event_add3dMouseClicked

    private void writeAllFiles(byte[][] by,FileOutputStream[] out){
        for(int i = 0; i < 3; i++){
       if(!(by[i] == null)){
            try{
           
         BufferedOutputStream   buff = new BufferedOutputStream(out[i]);
        buff.write(by[i], 0, by[i].length);
        buff.flush();
        buff.close();
        
        }
        catch(IOException e){
        OkOption ok = new OkOption(this, "Output Error");
        ok.setLabel1("Error writing 3D files. Pls try again");
        ok.showDialog();
        return;
        }
       
       }
       else{
       OkOption ok = new OkOption(this, null);
       ok.setLabel1("One or more files have not been selected. Please selected files to continue");
       ok.showDialog();
       return;
       }
        }
       OkOption ok = new OkOption(this, "3D ADDED");
        ok.setLabel1("3D added");
        ok.showDialog();
        
    }
    private void updateComponentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateComponentBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateComponentBtnActionPerformed

    private void buttMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttMouseClicked
        
    }//GEN-LAST:event_buttMouseClicked

    private void selObjMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selObjMouseClicked
        JFileChooser filechoser = new JFileChooser();
        filechoser.setDialogTitle("Choose .obj file");
        filechoser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int dia =  filechoser.showOpenDialog(this);
        if(dia == JFileChooser.APPROVE_OPTION){
        File file = filechoser.getSelectedFile();
       
        if(!file.getName().endsWith(".obj")){
        OkOption ok = new OkOption(this, "Wrong Selection");
        ok.setLabel1("Wrong file type selected. Please select an obj file");
        ok.showDialog();
        }
        
        else{
        objtextbox.setText(file.getName());
         fileout[0] = new File("KSim3DResource/"+file.getName());
        filebyte[0] = new byte[(int)file.length()];
        
        
            try {
                FileInputStream fis = new FileInputStream(file);
                BufferedInputStream bis = new BufferedInputStream(fis);
                bis.read(filebyte[0], 0, filebyte[0].length);
                bis.close();
                
                outfile[0] = new FileOutputStream(fileout[0]);
            } catch (Exception e) {
            }
        
        }
        }
    }//GEN-LAST:event_selObjMouseClicked

    private void selMtlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selMtlMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose a .mtl file");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int dia = filechooser.showOpenDialog(this);
        if(dia == JFileChooser.APPROVE_OPTION){
        File file = filechooser.getSelectedFile();
        if(!file.getName().endsWith(".mtl")){
        OkOption ok = new OkOption(this, "Wrong Selection");
        ok.setLabel1("Wrong file type selected. Please select a mtl file");
        ok.showDialog();
        }
        else{
        mtltext.setText(file.getName());
        fileout[1] = new File("KSim3DResource/"+file.getName());
        filebyte[1] = new byte[(int)file.length()];
            try {
        
                FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);
        bis.read(filebyte[1], 0, filebyte[1].length);
        bis.close();
        
        outfile[1] = new FileOutputStream(fileout[1]);
            } catch (Exception e) {
            }
        
        }
        }
    }//GEN-LAST:event_selMtlMouseClicked

    private void selImgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selImgMouseClicked
        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Choose an image file");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int dia = filechooser.showOpenDialog(this);
        if(dia == JFileChooser.APPROVE_OPTION){
        File file = filechooser.getSelectedFile();
        if(!file.getName().endsWith(".png")){
        OkOption ok = new OkOption(this, "Wrong Selection");
        ok.setLabel1("Wrong file type selected. Please select a png file");
        ok.showDialog();
        }
        
        else{
        imgtext.setText(file.getName());
        fileout[2] = new File("KSim3DResource/"+file.getName());
        filebyte[2] = new byte[(int)file.length()];
        
            try {
                FileInputStream fis = new FileInputStream(file);
                BufferedInputStream bis = new BufferedInputStream(fis);
                bis.read(filebyte[2], 0, filebyte[2].length);
                bis.close();
                
                outfile[2] = new FileOutputStream(fileout[2]);
            } catch (Exception e) {
            }
        }}
    }//GEN-LAST:event_selImgMouseClicked

    private void buttActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttActionPerformed
writeAllFiles( filebyte, outfile);        // TODO add your handling code here:
    }//GEN-LAST:event_buttActionPerformed

    private void moduleTypeUpdateBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_moduleTypeUpdateBtnMouseClicked
     aamt= new AdminAddModuleTypePane("edit", controller);  
     puf.addPanels(aamt);
     puf.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_moduleTypeUpdateBtnMouseClicked

    private void loadCandidates1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loadCandidates1MouseClicked
        listSimComponentsSelected.removeAllElements();

        if (!rulesComponentList.isSelectionEmpty()) {
            listSimComponentsCandidates.removeAllElements();
            selectedValue = (SimComponent) rulesComponentList.getSelectedValue();
            // retrieve other Component appart from selected Componennt
            int selectedValuePosition = temporaryList.indexOf(selectedValue);
            // add to starSelected
            listSimComponentsSelected.addElement(selectedValue);
            //iterate remaining tempList
            for (int i = 0; i < temporaryList.size(); i++) {
                // add to candidate List
                if (i != selectedValuePosition) {
                    listSimComponentsCandidates.addElement(temporaryList.get(i));
                }

            }
        }
    }//GEN-LAST:event_loadCandidates1MouseClicked

    private void addNewRulesBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewRulesBtn1MouseClicked
        SimComponent tempComponent = (SimComponent) listSimComponentsSelected.get(0);

        List<SimComponent> listed = new LinkedList();
        for (int i = 0; i < listSimComponentsSuccessors.getSize(); i++) {
            listed.add((SimComponent) listSimComponentsSuccessors.get(i));

        }
        //convert a List Collection to a set and Persist
        tempComponent.setPersistentSuccessors(listed);
        controller.mergeObject(tempComponent);
        //clear all listmodels for next
        listSimComponentsSelected.removeAllElements();
        listSimComponentsSuccessors.removeAllElements();
        listSimComponentsCandidates.removeAllElements();
    }//GEN-LAST:event_addNewRulesBtn1MouseClicked

    
    private void arrowAllocation(int selected) {

        for (int i = 5; i >= 0; i--) {
            if (i == selected) {
                temporaryLabels[i].setIcon(arrow);

            } else {
                temporaryLabels[i].setIcon(null);
            }

        }

    }

    private void customClearTextField(JTextField clear) {
        clear.setText(null);
    }

    private void customSetTextFieldEditable(JTextField customSetText) {
        customSetText.setEditable(true);
    }
//method to read image files and convert to byte array

    private static byte[] readFileToByte(File f) throws FileNotFoundException, IOException {
        // create file input stream to read data from file
        FileInputStream fileIn = new FileInputStream(f);

        //create byte array to store image data
        byte[] toArrayByte = new byte[(int) f.length()];

        //read the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < toArrayByte.length && (numRead = fileIn.read(toArrayByte, offset, toArrayByte.length - offset)) >= 0) {
            offset += numRead;
        }
        fileIn.close();


        return toArrayByte;
    }

    private static String readFile(File filename) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));

        StringBuilder sb = new StringBuilder();
        String line = br.readLine();
        while (line != null) {
            sb.append(line);
            sb.append("\n");
            line = br.readLine();

        }
        br.close();
        return sb.toString();


    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws UnsupportedLookAndFeelException {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        //UIManager.setLookAndFeel(new AluminiumLookAndFeel());



        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminSimView().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList SimModuleTypeList;
    private javax.swing.JButton add3d;
    private javax.swing.JLabel addComponentErrorLabel;
    private javax.swing.JPanel addModulePane;
    private javax.swing.JButton addNewBtn;
    private javax.swing.JCheckBox addNewCheckBox;
    private javax.swing.JButton addNewComponentBtn;
    private javax.swing.JComboBox addNewComponentModuleCombo;
    private javax.swing.JButton addNewModuleBtn;
    private javax.swing.JLabel addNewModuleDescriptionLabel;
    private javax.swing.JTextArea addNewModuleDescriptionTxt;
    private javax.swing.JLabel addNewModuleErrorLabel;
    private javax.swing.JLabel addNewModuleNameLabel;
    private javax.swing.JTextField addNewModuleNameTxt;
    private javax.swing.JLabel addNewModuleVersionLabel;
    private javax.swing.JTextField addNewModuleVersionTxt;
    private javax.swing.JCheckBox addNewModulesCheckBox;
    private javax.swing.JButton addNewRulesBtn;
    private javax.swing.JButton addNewRulesBtn1;
    private javax.swing.JLabel addNewSimModuleTaskOnSelect1;
    private javax.swing.JLabel addNewSimModuleTaskOnSelect2;
    private javax.swing.JLabel addNewSimModuleTaskOnSelect3;
    private javax.swing.JLabel addNewSimModuleTaskOnSelect4;
    private javax.swing.JButton addNewUserBtn;
    private javax.swing.JCheckBox addNewUserCheckBox;
    private javax.swing.JCheckBox addScriptFileCheckBox;
    private javax.swing.JLabel addremoveTips;
    private javax.swing.ButtonGroup adminTaskComponentBtnGroup;
    private javax.swing.ButtonGroup adminTaskModuleButtonGroup;
    private javax.swing.ButtonGroup adminTaskSimulatorUserButtonGroup;
    private javax.swing.JTabbedPane adminTaskTabPane;
    private javax.swing.JLabel artStatus;
    private javax.swing.JButton butt;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox chooseModuleTypeCombo;
    private javax.swing.JLabel chooseModuleTypeComboLabel;
    private javax.swing.JButton clearTextField;
    private javax.swing.JLabel componentDescription;
    private javax.swing.JLabel componentDescriptionImage;
    private javax.swing.JPanel componentDescriptionImagePanel;
    private javax.swing.JLabel componentDescriptionLabel;
    private javax.swing.JTextArea componentDescriptionTxt;
    private javax.swing.JLabel componentId;
    private javax.swing.JComboBox componentModuleComboBox;
    private javax.swing.JComboBox componentModuleTypeComboBox;
    private javax.swing.JLabel componentNameLabel;
    private javax.swing.JTextField componentNameTxt;
    private javax.swing.JPanel componentPane;
    private javax.swing.JLabel componentRawIconImage;
    private javax.swing.JLabel componentRawIconLabel;
    private javax.swing.JPanel componentRawIconPane;
    private javax.swing.JPanel componentTab;
    private javax.swing.JLabel deleteComponent;
    private javax.swing.JLabel deleteModule;
    private javax.swing.JLabel deleteModuleType;
    private javax.swing.JLabel deleteUserExisting;
    private javax.swing.JLabel descLabel;
    private javax.swing.JPanel editComponentPanel;
    private javax.swing.JLabel editModuleDescriptionLabel;
    private javax.swing.JTextArea editModuleDescriptionTxt;
    private javax.swing.JLabel editModuleIdLabel;
    private javax.swing.JTextField editModuleIdTxt;
    private javax.swing.JLabel editModuleNameLabel;
    private javax.swing.JTextField editModuleNameTxt;
    private javax.swing.JLabel editModuleNoOfComponentsLabel;
    private javax.swing.JTextField editModuleNoOfComponentsTxt;
    private javax.swing.JPanel editModulePane;
    private javax.swing.JLabel editModuleVersionLabel;
    private javax.swing.JTextField editModuleVersionTxt;
    private javax.swing.JPanel editPane;
    private javax.swing.JLabel editPaneErrorLabel;
    private javax.swing.JTextArea editPaneModuleTypeDesc;
    private javax.swing.JTextField editPaneModuleTypeId;
    private javax.swing.JTextField editPaneModuleTypeTypeName;
    private javax.swing.JLabel editUserFirstNameLabel;
    private javax.swing.JTextField editUserFirstNameTxt;
    private javax.swing.JLabel editUserLastNameLabel;
    private javax.swing.JTextField editUserLastNameTxt;
    private javax.swing.JLabel editUserMiddleNameLabel;
    private javax.swing.JTextField editUserMiddleNameTxt;
    private javax.swing.JLabel editUserPassLabel;
    private javax.swing.JPasswordField editUserPassTxt;
    private javax.swing.JLabel editUserUserNameLabel;
    private javax.swing.JTextField editUserUserNameTxt;
    private javax.swing.JLabel enlarged2dimageLabel;
    private javax.swing.JLabel errorLabeL;
    private javax.swing.JLabel errorLabel2;
    private javax.swing.JCheckBox existingCheckBox;
    private javax.swing.JCheckBox existingModulesCheckBox;
    private javax.swing.JLabel existingRefresh;
    private javax.swing.JPanel existingUserEditPane;
    private javax.swing.JCheckBox existingUsersCheckBox;
    private javax.swing.JList existingUsersList;
    private javax.swing.JTextField imgtext;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel loadAllComponents;
    private javax.swing.JLabel loadCandidates;
    private javax.swing.JLabel loadCandidates1;
    private javax.swing.JLabel loadComponentInfo;
    private javax.swing.JLabel loadModuleInfo;
    private javax.swing.JComboBox loadModuleTypeCombo;
    private javax.swing.JLabel loadModuleTypeInfoBtn;
    private javax.swing.JLabel loadUserExisting;
    private javax.swing.JLabel modType;
    private javax.swing.JTextField moduleIdTxt;
    private javax.swing.JPanel modulePane;
    private javax.swing.JLabel moduleRefresh;
    private javax.swing.JPanel moduleTab;
    private javax.swing.JButton moduleTypeAddBtn;
    private javax.swing.JPanel moduleTypeExisting;
    private javax.swing.JPanel moduleTypeNew;
    private javax.swing.JPanel moduleTypeTab;
    private javax.swing.JButton moduleTypeUpdateBtn;
    private javax.swing.JPanel modulesListMiniPane;
    private javax.swing.JButton moveAllBtn;
    private javax.swing.JButton moveOneBtn;
    private javax.swing.JTextField mtltext;
    private javax.swing.JCheckBox newCheckBox;
    private javax.swing.JTextArea newSimModuleTypeDesc;
    private javax.swing.JTextField newSimModuleTypeNameField;
    private javax.swing.JLabel noOfModulesLabelTxt;
    private javax.swing.JTextField objtextbox;
    private javax.swing.JButton returnAllBtn;
    private javax.swing.JButton returnOneBtn;
    private javax.swing.JPanel ruleTab;
    private javax.swing.JList rulesCandidateComponentList;
    private javax.swing.JList rulesComponentList;
    private javax.swing.JList rulesSelectedComponentList;
    private javax.swing.JList rulesSuccessorComponentsList;
    private javax.swing.JLabel selImg;
    private javax.swing.JLabel selMtl;
    private javax.swing.JLabel selObj;
    private javax.swing.JList simComponenTabList;
    private javax.swing.JList simModuleList;
    private javax.swing.JButton updateBtn;
    private javax.swing.JButton updateComponentBtn;
    private javax.swing.JButton updateModuleBtn;
    private javax.swing.JButton updateUserBtn;
    private javax.swing.JTextField uploadDescriptionIconImageTxt;
    private javax.swing.JButton uploadDescriptionImageBtn;
    private javax.swing.JButton uploadIconImageBtn;
    private javax.swing.JTextField uploadIconImageTxt;
    private javax.swing.JButton uploadSolidImageBtn;
    private javax.swing.JTextField uploadSolidImageTxt;
    private javax.swing.JButton uploadWiredFrameImageBtn;
    private javax.swing.JTextField uploadWiredFrameImageTxt;
    private javax.swing.JLabel userAddConfirmPassLabel;
    private javax.swing.JPasswordField userAddConfirmPassTxt;
    private javax.swing.JLabel userAddErrorLabel;
    private javax.swing.JTextField userAddFirstNameTxt;
    private javax.swing.JLabel userAddLastNameLabel;
    private javax.swing.JTextField userAddLastNameTxt;
    private javax.swing.JLabel userAddMiddleNameLabel;
    private javax.swing.JTextField userAddMiddleNameTxt;
    private javax.swing.JPanel userAddPane;
    private javax.swing.JLabel userAddPassLabel;
    private javax.swing.JPasswordField userAddPassTxt;
    private javax.swing.JLabel userAddUserNameLabel;
    private javax.swing.JTextField userAddUserNameTxt;
    private javax.swing.JLabel userAddfirstNameLabel;
    private javax.swing.JScrollPane userExistingScrollPane;
    private javax.swing.JScrollPane userExistingScrollPane1;
    private javax.swing.JPanel userTab;
    private javax.swing.JLabel userTabErrorLabel;
    private javax.swing.JPanel usersExistingMiniPanel;
    private javax.swing.JPanel usersExistingPanel;
    private javax.swing.JLabel usersExistingRefresh;
    private javax.swing.JCheckBox viewExistingCheckBox;
    private javax.swing.JPanel welcomeTab;
    // End of variables declaration//GEN-END:variables
}

class ListRenderer implements ListCellRenderer {

    DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();

    ListRenderer() {
    }

    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index,
            boolean isSelected, boolean cellHasFocus) {
        Border border = BorderFactory.createTitledBorder("");

        JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index,
                isSelected, cellHasFocus);
        SimComponent s = (SimComponent) value;


        renderer.setBorder(BorderFactory.createTitledBorder(""));

        try {
            renderer.setIcon(s.getIconImage());
        } catch (IOException ex) {
            Logger.getLogger(IconListRenderer.class.getName()).log(Level.SEVERE, null, ex);
        }

        return renderer;
    }
}
