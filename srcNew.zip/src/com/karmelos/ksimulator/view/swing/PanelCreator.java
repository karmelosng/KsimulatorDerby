/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.karmelos.ksimulator.view.swing;

import javax.swing.JPanel;

/**
 *
 * @author jumoke
 */
public class PanelCreator  extends JPanel{

    public PanelCreator() {
    }
    
}
