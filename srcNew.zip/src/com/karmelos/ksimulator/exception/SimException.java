package com.karmelos.ksimulator.exception;

public class SimException extends Exception {

	public SimException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2302873620656466229L;

	
}
